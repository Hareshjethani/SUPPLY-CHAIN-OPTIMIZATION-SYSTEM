import React, { useState } from 'react';
import LinearProgramming from './components/LinearProgramming';
import AssignmentProblem from './components/AssignmentProblem';
import TransportationProblem from './components/TransportationProblem';
import Dashboard from './components/Dashboard';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const tabs = [
    { id: 'dashboard', name: 'Dashboard', icon: '📊' },
    { id: 'lp', name: 'Linear Programming', icon: '📈' },
    { id: 'assignment', name: 'Assignment Problem', icon: '👥' },
    { id: 'transportation', name: 'Transportation', icon: '🚚' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                TechParts Inc. 
                <span className="text-primary-600"> Supply Chain Optimizer</span>
              </h1>
              <p className="mt-1 text-sm text-gray-600">
                Operations Research & Optimization System
              </p>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              <div className="text-right">
                <p className="text-xs text-gray-500">Powered by</p>
                <p className="text-sm font-semibold text-gray-700">Scipy • NumPy • React</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-10 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-1 overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`
                  px-6 py-4 font-medium text-sm whitespace-nowrap transition-all duration-200
                  ${activeTab === tab.id
                    ? 'border-b-2 border-primary-600 text-primary-600 bg-primary-50'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }
                `}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.name}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-fade-in">
          {activeTab === 'dashboard' && <Dashboard setActiveTab={setActiveTab} />}
          {activeTab === 'lp' && <LinearProgramming />}
          {activeTab === 'assignment' && <AssignmentProblem />}
          {activeTab === 'transportation' && <TransportationProblem />}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-3">About</h3>
              <p className="text-gray-400 text-sm">
                Advanced optimization system for supply chain management using
                Linear Programming, Assignment, and Transportation algorithms.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-3">Methods</h3>
              <ul className="text-gray-400 text-sm space-y-1">
                <li>• Simplex Algorithm (Linear Programming)</li>
                <li>• Hungarian Algorithm (Assignment)</li>
                <li>• Vogel's Approximation Method (Transportation)</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-3">Technology</h3>
              <ul className="text-gray-400 text-sm space-y-1">
                <li>• Backend: Python, Flask, Scipy</li>
                <li>• Frontend: React, Vite, Tailwind CSS</li>
                <li>• Visualization: Recharts</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400 text-sm">
            <p>&copy; 2025 TechParts Inc. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
