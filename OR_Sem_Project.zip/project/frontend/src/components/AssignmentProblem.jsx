import React, { useState, useEffect } from 'react';
import { assignmentAPI } from '../api';

function AssignmentProblem() {
  const [problemData, setProblemData] = useState(null);
  const [solution, setSolution] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showSteps, setShowSteps] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editedData, setEditedData] = useState(null);

  useEffect(() => {
    loadProblemData();
  }, []);

  const loadProblemData = async () => {
    try {
      const response = await assignmentAPI.getData();
      setProblemData(response.data);
      setEditedData(JSON.parse(JSON.stringify(response.data)));
    } catch (err) {
      setError('Failed to load problem data');
    }
  };

  const handleSolve = async () => {
    setLoading(true);
    setError(null);
    setSolution(null);
    try {
      const dataToSolve = editMode ? editedData : problemData;
      const response = await assignmentAPI.solve(dataToSolve);
      setSolution(response.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to solve problem');
    } finally {
      setLoading(false);
    }
  };

  const handleEditToggle = () => {
    if (!editMode) {
      setEditedData(JSON.parse(JSON.stringify(problemData)));
    }
    setEditMode(!editMode);
    setSolution(null);
  };

  const handleReset = () => {
    loadProblemData();
    setSolution(null);
    setEditMode(false);
  };

  const updateCostMatrix = (row, col, value) => {
    const newData = { ...editedData };
    newData.cost_matrix[row][col] = parseFloat(value) || 0;
    setEditedData(newData);
  };

  const getEfficiencyColor = (rank) => {
    switch (rank) {
      case 'Optimal': return 'text-green-600 bg-green-50';
      case 'Good': return 'text-blue-600 bg-blue-50';
      case 'Average': return 'text-yellow-600 bg-yellow-50';
      default: return 'text-orange-600 bg-orange-50';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card bg-gradient-to-r from-purple-500 to-purple-600 text-white">
        <h2 className="text-3xl font-bold mb-2">👥 Assignment Problem</h2>
        <p className="text-purple-100">
          Optimal task-worker allocation using the Hungarian Algorithm
        </p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">{error}</p>
        </div>
      )}

      {/* Edit/Reset Controls */}
      {problemData && (
        <div className="card bg-gradient-to-r from-purple-50 to-pink-50">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold text-gray-800">
                {editMode ? '✏️ Edit Mode: Modify Time Matrix' : '📋 Using Default Problem Data'}
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                {editMode ? 'Change completion times in the matrix below' : 'Click Edit to customize worker-task times'}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleEditToggle}
                className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                  editMode 
                    ? 'bg-gray-500 text-white hover:bg-gray-600' 
                    : 'bg-purple-500 text-white hover:bg-purple-600'
                }`}
              >
                {editMode ? '📖 View Mode' : '✏️ Edit Problem'}
              </button>
              {editMode && (
                <button
                  onClick={handleReset}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 transition-colors"
                >
                  🔄 Reset to Default
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Problem Statement */}
      <div className="card">
        <h3 className="text-xl font-bold mb-4">Problem Statement</h3>
        <div className="bg-gray-50 p-4 rounded-lg">
          <p className="text-gray-700">
            <strong>Objective:</strong> Assign 5 specialized assembly tasks to 5 workers to minimize total completion time.
            Each worker is assigned exactly one task, and each task is assigned to exactly one worker.
          </p>
        </div>
      </div>

      {/* Workers and Tasks */}
      {(editMode ? editedData : problemData) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Workers */}
          <div className="card">
            <h3 className="text-lg font-bold mb-4">👤 Workers</h3>
            <div className="space-y-2">
              {(editMode ? editedData : problemData).workers.map((worker) => (
                <div key={worker.id} className="p-3 bg-purple-50 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="font-semibold">{worker.name}</p>
                    <p className="text-sm text-gray-600">{worker.experience} experience</p>
                  </div>
                  <span className="text-xs px-2 py-1 bg-purple-200 text-purple-800 rounded">
                    {worker.skill_level}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Tasks */}
          <div className="card">
            <h3 className="text-lg font-bold mb-4">📋 Tasks</h3>
            <div className="space-y-2">
              {(editMode ? editedData : problemData).tasks.map((task) => (
                <div key={task.id} className="p-3 bg-blue-50 rounded-lg">
                  <p className="font-semibold">{task.name}</p>
                  <p className="text-sm text-gray-600">{task.description}</p>
                  <div className="mt-1 flex gap-2">
                    <span className="text-xs px-2 py-1 bg-blue-200 text-blue-800 rounded">
                      {task.difficulty}
                    </span>
                    <span className="text-xs px-2 py-1 bg-orange-200 text-orange-800 rounded">
                      {task.priority}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Cost Matrix */}
      {(editMode ? editedData : problemData) && (
        <div className="card overflow-x-auto">
          <h3 className="text-lg font-bold mb-4">⏱️ Time Matrix (hours) {editMode && '- Click to Edit'}</h3>
          <p className="text-sm text-gray-600 mb-4">
            {editMode ? 'Edit the completion time for each worker-task combination' : 'Time required for each worker to complete each task'}
          </p>
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th className="table-header">Worker</th>
                  {(editMode ? editedData : problemData).tasks.map((task) => (
                    <th key={task.id} className="table-header text-center">
                      {task.name.split(' ')[0]}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {(editMode ? editedData : problemData).workers.map((worker, i) => (
                  <tr key={worker.id} className="hover:bg-gray-50">
                    <td className="table-cell font-medium">{worker.name}</td>
                    {(editMode ? editedData : problemData).cost_matrix[i].map((time, j) => (
                      <td key={j} className="table-cell text-center">
                        {editMode ? (
                          <input
                            type="number"
                            value={time}
                            onChange={(e) => updateCostMatrix(i, j, e.target.value)}
                            className="w-16 px-2 py-1 border rounded text-center"
                            step="0.1"
                            min="0"
                          />
                        ) : (
                          <span className={`inline-block px-3 py-1 rounded ${
                            time <= 4 ? 'bg-green-100 text-green-800' :
                            time <= 6 ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {time}
                          </span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Solve Button */}
      <div className="text-center">
        <button
          onClick={handleSolve}
          disabled={loading || !problemData}
          className="btn-primary"
        >
          {loading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Solving...
            </span>
          ) : (
            '🧮 Solve Using Hungarian Algorithm'
          )}
        </button>
      </div>

      {/* Solution */}
      {solution && solution.success && (
        <div className="space-y-6 animate-slide-up">
          {/* Summary */}
          <div className="card bg-green-50 border-l-4 border-green-500">
            <h3 className="text-2xl font-bold text-green-800 mb-2">
              Minimum Total Time: {solution.total_time} hours
            </h3>
            <p className="text-green-700">Optimal assignment found using Hungarian Algorithm!</p>
          </div>

          {/* Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="card bg-blue-50">
              <p className="text-sm text-gray-600 mb-1">Average Time</p>
              <p className="text-3xl font-bold text-blue-600">{solution.average_time}</p>
              <p className="text-xs text-gray-500">hours per task</p>
            </div>
            <div className="card bg-purple-50">
              <p className="text-sm text-gray-600 mb-1">Longest Task</p>
              <p className="text-3xl font-bold text-purple-600">{solution.max_time}</p>
              <p className="text-xs text-gray-500">hours</p>
            </div>
            <div className="card bg-green-50">
              <p className="text-sm text-gray-600 mb-1">Shortest Task</p>
              <p className="text-3xl font-bold text-green-600">{solution.min_time}</p>
              <p className="text-xs text-gray-500">hours</p>
            </div>
          </div>

          {/* Assignments */}
          <div className="card">
            <h3 className="text-xl font-bold mb-4">Optimal Assignments</h3>
            <div className="space-y-3">
              {solution.assignment_details?.map((assignment, index) => (
                <div key={index} className="p-4 bg-gray-50 rounded-lg flex items-center justify-between hover:shadow-md transition-shadow">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-purple-500 text-white rounded-full flex items-center justify-center font-bold">
                        {assignment.worker_name[0]}
                      </div>
                      <div>
                        <p className="font-semibold text-lg">{assignment.worker_name}</p>
                        <p className="text-sm text-gray-600">{assignment.worker_experience}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="text-center px-4">
                      <p className="text-2xl">→</p>
                    </div>
                    
                    <div className="flex-1">
                      <p className="font-semibold">{assignment.task_name}</p>
                      <p className="text-sm text-gray-600">{assignment.task_description}</p>
                    </div>
                  </div>

                  <div className="text-right ml-4">
                    <p className="text-2xl font-bold text-purple-600">{assignment.completion_time}</p>
                    <p className="text-xs text-gray-500">hours</p>
                    <span className={`inline-block mt-1 px-2 py-1 text-xs rounded ${getEfficiencyColor(assignment.efficiency_rank)}`}>
                      {assignment.efficiency_rank}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Comparison with Alternatives */}
          {solution.comparisons && (
            <div className="card">
              <h3 className="text-xl font-bold mb-4">📊 Comparison with Other Strategies</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <span className="font-medium">Hungarian Algorithm (Optimal)</span>
                  <span className="text-2xl font-bold text-green-600">{solution.comparisons.optimal} hrs</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                  <span className="font-medium">Greedy Strategy</span>
                  <span className="text-xl font-bold text-blue-600">{solution.comparisons.greedy} hrs</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                  <span className="font-medium">Random Assignment (avg)</span>
                  <span className="text-xl font-bold text-yellow-600">{solution.comparisons.random_average.toFixed(1)} hrs</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                  <span className="font-medium">Worst Case</span>
                  <span className="text-xl font-bold text-red-600">{solution.comparisons.worst_case} hrs</span>
                </div>
              </div>

              <div className="mt-4 p-4 bg-primary-50 rounded-lg">
                <p className="text-sm">
                  <strong>Efficiency Gain:</strong>
                </p>
                <p className="text-sm mt-1">
                  • {solution.comparisons.improvement_vs_greedy.toFixed(2)}% better than greedy approach
                </p>
                <p className="text-sm">
                  • {solution.comparisons.improvement_vs_random.toFixed(2)}% better than random assignment
                </p>
              </div>
            </div>
          )}

          {/* Algorithm Info */}
          <div className="card bg-purple-50">
            <h3 className="text-lg font-bold mb-2">🔬 Algorithm Details</h3>
            <div className="space-y-2 text-sm">
              <p><strong>Method:</strong> Hungarian Algorithm (Kuhn-Munkres)</p>
              <p><strong>Status:</strong> {solution.message}</p>
              <p><strong>Complexity:</strong> O(n³) where n = 5</p>
              <p><strong>Optimality:</strong> Guaranteed optimal solution</p>
              <p><strong>Workers × Tasks:</strong> 5 × 5 = 25 possible combinations</p>
            </div>
            
            {solution.algorithm_steps && solution.algorithm_steps.length > 0 && (
              <div className="mt-4">
                <button
                  onClick={() => setShowSteps(!showSteps)}
                  className="btn-primary w-full"
                >
                  {showSteps ? '🔼 Hide Algorithm Steps' : '🔽 Show Algorithm Steps (Hungarian Method)'}
                </button>
              </div>
            )}
          </div>

          {/* Hungarian Algorithm Steps */}
          {showSteps && solution.algorithm_steps && (
            <div className="card bg-gradient-to-br from-purple-50 to-pink-50">
              <h3 className="text-2xl font-bold mb-4 text-purple-800">📊 Hungarian Algorithm Steps</h3>
              <p className="text-sm text-gray-700 mb-6">
                The Hungarian Algorithm finds the optimal assignment by systematically reducing the cost matrix 
                and identifying zero-cost assignments that minimize the total completion time.
              </p>
              
              <div className="space-y-6">
                {solution.algorithm_steps.map((step, index) => (
                  <div key={index} className="bg-white p-6 rounded-lg shadow-md border-l-4 border-purple-500">
                    <div className="mb-3">
                      <h4 className="text-xl font-bold text-purple-700">
                        Step {step.step}: {step.title}
                      </h4>
                      <p className="text-gray-700 mt-2">{step.description}</p>
                    </div>
                    
                    {step.matrix && (
                      <div className="overflow-x-auto mt-4">
                        <table className="min-w-full text-sm border-collapse">
                          <thead>
                            <tr className="bg-purple-100">
                              <th className="border px-3 py-2 font-semibold">Worker</th>
                              {step.task_names?.map((task, i) => (
                                <th key={i} className="border px-3 py-2 font-semibold">
                                  {task.split(' ')[0]}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {step.matrix.map((row, i) => (
                              <tr key={i} className="hover:bg-gray-50">
                                <td className="border px-3 py-2 font-medium">
                                  {step.worker_names?.[i] || `Worker ${i+1}`}
                                </td>
                                {row.map((cell, j) => {
                                  const isAssignment = step.assignment_matrix && 
                                                      step.assignment_matrix[i][j] === 1;
                                  const isZero = cell === 0;
                                  return (
                                    <td 
                                      key={j} 
                                      className={`border px-3 py-2 text-center font-semibold ${
                                        isAssignment ? 'bg-green-200 text-green-900' :
                                        isZero ? 'bg-yellow-100 text-yellow-900' :
                                        'text-gray-700'
                                      }`}
                                    >
                                      {isAssignment ? `✓ ${cell}` : cell.toFixed(1)}
                                    </td>
                                  );
                                })}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                    
                    {step.row_mins && (
                      <div className="mt-3 p-3 bg-blue-50 rounded">
                        <p className="text-sm">
                          <strong>Row Minimums:</strong> {step.row_mins.map(v => v.toFixed(1)).join(', ')}
                        </p>
                      </div>
                    )}
                    
                    {step.col_mins && (
                      <div className="mt-3 p-3 bg-green-50 rounded">
                        <p className="text-sm">
                          <strong>Column Minimums:</strong> {step.col_mins.map(v => v.toFixed(1)).join(', ')}
                        </p>
                      </div>
                    )}
                    
                    {step.zero_positions && (
                      <div className="mt-3 p-3 bg-yellow-50 rounded">
                        <p className="text-sm">
                          <strong>Zero Positions:</strong> Found at {step.zero_positions.length} locations
                        </p>
                      </div>
                    )}
                    
                    {step.assignments && (
                      <div className="mt-3 p-3 bg-green-50 rounded">
                        <p className="text-sm font-semibold mb-2">
                          <strong>Optimal Assignments:</strong>
                        </p>
                        {step.assignments.map(([i, j], idx) => (
                          <p key={idx} className="text-sm ml-4">
                            • {step.worker_names[i]} → {step.task_names[j].split(' ')[0]}
                          </p>
                        ))}
                        <p className="text-sm mt-2 font-bold text-green-700">
                          Total Cost: {step.total_cost?.toFixed(1)} hours
                        </p>
                      </div>
                    )}
                    
                    {step.note && (
                      <div className="mt-3 p-3 bg-gray-50 rounded border-l-2 border-gray-400">
                        <p className="text-sm text-gray-700">
                          <strong>Note:</strong> {step.note}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              
              <div className="mt-6 p-4 bg-green-50 rounded-lg border-2 border-green-300">
                <h4 className="font-bold text-green-800 mb-2">✅ Optimal Assignment Found</h4>
                <p className="text-sm text-gray-700">
                  The Hungarian Algorithm has found the optimal assignment with a minimum total completion time of 
                  <strong className="text-green-700"> {solution.total_time} hours</strong>.
                  This is guaranteed to be the best possible assignment.
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default AssignmentProblem;
