import React, { useState, useEffect } from 'react';
import { solveAll } from '../api';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#0ea5e9', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444'];

function Dashboard({ setActiveTab }) {
  const [loading, setLoading] = useState(false);
  const [solutions, setSolutions] = useState(null);
  const [error, setError] = useState(null);

  const handleSolveAll = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await solveAll();
      setSolutions(response.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to solve problems');
    } finally {
      setLoading(false);
    }
  };

  const features = [
    {
      title: 'Linear Programming',
      description: 'Optimize production quantities to maximize profit with resource constraints',
      icon: '📈',
      color: 'bg-blue-500',
      tab: 'lp'
    },
    {
      title: 'Assignment Problem',
      description: 'Assign tasks to workers optimally using Hungarian Algorithm',
      icon: '👥',
      color: 'bg-purple-500',
      tab: 'assignment'
    },
    {
      title: 'Transportation Problem',
      description: 'Minimize distribution costs from factories to warehouses',
      icon: '🚚',
      color: 'bg-green-500',
      tab: 'transportation'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="card bg-gradient-to-r from-primary-600 to-purple-600 text-white">
        <div className="text-center py-8">
          <h2 className="text-4xl font-bold mb-4">
            Welcome to Supply Chain Optimizer
          </h2>
          <p className="text-xl text-blue-100 mb-6">
            Solve complex optimization problems with advanced algorithms
          </p>
          <button
            onClick={handleSolveAll}
            disabled={loading}
            className="bg-white text-primary-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
          >
            {loading ? (
              <span className="flex items-center">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Solving All Problems...
              </span>
            ) : (
              '🚀 Solve All Problems'
            )}
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">{error}</p>
        </div>
      )}

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {features.map((feature) => (
          <div
            key={feature.tab}
            className="card cursor-pointer transform hover:scale-105 transition-transform duration-200"
            onClick={() => setActiveTab(feature.tab)}
          >
            <div className={`${feature.color} w-16 h-16 rounded-lg flex items-center justify-center text-3xl mb-4`}>
              {feature.icon}
            </div>
            <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
            <p className="text-gray-600 mb-4">{feature.description}</p>
            <button className="text-primary-600 font-semibold hover:text-primary-700">
              Explore →
            </button>
          </div>
        ))}
      </div>

      {/* Results Section */}
      {solutions && (
        <div className="space-y-6 animate-slide-up">
          <h2 className="text-2xl font-bold">Optimization Results</h2>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* LP Summary */}
            {solutions.linear_programming?.success && (
              <div className="card bg-blue-50 border-l-4 border-blue-500">
                <h3 className="font-semibold text-lg mb-2">Linear Programming</h3>
                <div className="space-y-1">
                  <p className="text-2xl font-bold text-blue-600">
                    ${solutions.linear_programming.max_profit?.toLocaleString()}
                  </p>
                  <p className="text-sm text-gray-600">Maximum Profit</p>
                </div>
              </div>
            )}

            {/* Assignment Summary */}
            {solutions.assignment?.success && (
              <div className="card bg-purple-50 border-l-4 border-purple-500">
                <h3 className="font-semibold text-lg mb-2">Assignment Problem</h3>
                <div className="space-y-1">
                  <p className="text-2xl font-bold text-purple-600">
                    {solutions.assignment.total_time} hours
                  </p>
                  <p className="text-sm text-gray-600">Total Completion Time</p>
                </div>
              </div>
            )}

            {/* Transportation Summary */}
            {solutions.transportation?.success && (
              <div className="card bg-green-50 border-l-4 border-green-500">
                <h3 className="font-semibold text-lg mb-2">Transportation Problem</h3>
                <div className="space-y-1">
                  <p className="text-2xl font-bold text-green-600">
                    ${solutions.transportation.total_cost?.toLocaleString()}
                  </p>
                  <p className="text-sm text-gray-600">Minimum Transportation Cost</p>
                </div>
              </div>
            )}
          </div>

          {/* Detailed Results */}
          {solutions.linear_programming?.success && (
            <div className="card">
              <h3 className="text-xl font-bold mb-4">Production Plan (Linear Programming)</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={Object.entries(solutions.linear_programming.optimal_production || {}).map(([name, value]) => ({
                  name,
                  quantity: value
                }))}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="quantity" fill="#0ea5e9" name="Production Quantity" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}

      {/* Info Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-xl font-bold mb-4">📚 Algorithms Used</h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <span className="text-blue-500 mr-2">•</span>
              <div>
                <p className="font-semibold">Simplex Algorithm</p>
                <p className="text-sm text-gray-600">Linear programming optimization with O(n³) complexity</p>
              </div>
            </li>
            <li className="flex items-start">
              <span className="text-purple-500 mr-2">•</span>
              <div>
                <p className="font-semibold">Hungarian Algorithm</p>
                <p className="text-sm text-gray-600">Optimal assignment with O(n³) complexity</p>
              </div>
            </li>
            <li className="flex items-start">
              <span className="text-green-500 mr-2">•</span>
              <div>
                <p className="font-semibold">Vogel's Approximation + Linear Programming</p>
                <p className="text-sm text-gray-600">Transportation cost minimization</p>
              </div>
            </li>
          </ul>
        </div>

        <div className="card">
          <h3 className="text-xl font-bold mb-4">💼 Business Impact</h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <span className="text-green-500 text-xl mr-2">✓</span>
              <div>
                <p className="font-semibold">15-25% Cost Reduction</p>
                <p className="text-sm text-gray-600">In transportation and operations</p>
              </div>
            </li>
            <li className="flex items-start">
              <span className="text-green-500 text-xl mr-2">✓</span>
              <div>
                <p className="font-semibold">30% Better Resource Utilization</p>
                <p className="text-sm text-gray-600">Optimal allocation of materials and labor</p>
              </div>
            </li>
            <li className="flex items-start">
              <span className="text-green-500 text-xl mr-2">✓</span>
              <div>
                <p className="font-semibold">Real-time Decision Support</p>
                <p className="text-sm text-gray-600">Data-driven optimization capabilities</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
