import React, { useState, useEffect } from 'react';
import { transportationAPI } from '../api';

function TransportationProblem() {
  const [problemData, setProblemData] = useState(null);
  const [solution, setSolution] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showSteps, setShowSteps] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editedData, setEditedData] = useState(null);

  useEffect(() => {
    loadProblemData();
  }, []);

  const loadProblemData = async () => {
    try {
      const response = await transportationAPI.getData();
      setProblemData(response.data);
      setEditedData(JSON.parse(JSON.stringify(response.data)));
    } catch (err) {
      setError('Failed to load problem data');
    }
  };

  const handleSolve = async () => {
    setLoading(true);
    setError(null);
    setSolution(null);
    try {
      const dataToSolve = editMode ? editedData : problemData;
      const response = await transportationAPI.solve(dataToSolve);
      setSolution(response.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to solve problem');
    } finally {
      setLoading(false);
    }
  };

  const handleEditToggle = () => {
    if (!editMode) {
      setEditedData(JSON.parse(JSON.stringify(problemData)));
    }
    setEditMode(!editMode);
    setSolution(null);
  };

  const handleReset = () => {
    loadProblemData();
    setSolution(null);
    setEditMode(false);
  };

  const updateFactorySupply = (index, value) => {
    const newData = { ...editedData };
    newData.factories[index].supply = parseFloat(value) || 0;
    setEditedData(newData);
  };

  const updateWarehouseDemand = (index, value) => {
    const newData = { ...editedData };
    newData.warehouses[index].demand = parseFloat(value) || 0;
    setEditedData(newData);
  };

  const updateCostMatrix = (row, col, value) => {
    const newData = { ...editedData };
    newData.cost_matrix[row][col] = parseFloat(value) || 0;
    setEditedData(newData);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card bg-gradient-to-r from-green-500 to-green-600 text-white">
        <h2 className="text-3xl font-bold mb-2">🚚 Transportation Problem</h2>
        <p className="text-green-100">
          Minimize distribution costs from factories to warehouses
        </p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">{error}</p>
        </div>
      )}

      {/* Edit/Reset Controls */}
      {problemData && (
        <div className="card bg-gradient-to-r from-green-50 to-emerald-50">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold text-gray-800">
                {editMode ? '✏️ Edit Mode: Modify Supply, Demand & Costs' : '📋 Using Default Problem Data'}
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                {editMode ? 'Change values below and click Solve to see results' : 'Click Edit to customize the transportation problem'}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleEditToggle}
                className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                  editMode 
                    ? 'bg-gray-500 text-white hover:bg-gray-600' 
                    : 'bg-green-500 text-white hover:bg-green-600'
                }`}
              >
                {editMode ? '📖 View Mode' : '✏️ Edit Problem'}
              </button>
              {editMode && (
                <button
                  onClick={handleReset}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 transition-colors"
                >
                  🔄 Reset to Default
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Problem Statement */}
      <div className="card">
        <h3 className="text-xl font-bold mb-4">Problem Statement</h3>
        <div className="bg-gray-50 p-4 rounded-lg">
          <p className="text-gray-700">
            <strong>Objective:</strong> Minimize total transportation costs while distributing products from 
            4 factories to 5 warehouses, meeting all demand requirements and respecting supply constraints.
          </p>
          {(editMode ? editedData : problemData) && (
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <p className="font-semibold">Total Supply:</p>
                <p className="text-2xl text-green-600">
                  {(editMode ? editedData : problemData).factories.reduce((sum, f) => sum + f.supply, 0)} units
                </p>
              </div>
              <div>
                <p className="font-semibold">Total Demand:</p>
                <p className="text-2xl text-blue-600">
                  {(editMode ? editedData : problemData).warehouses.reduce((sum, w) => sum + w.demand, 0)} units
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Factories and Warehouses */}
      {(editMode ? editedData : problemData) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Factories */}
          <div className="card">
            <h3 className="text-lg font-bold mb-4">🏭 Factories (Supply) {editMode && '- Editable'}</h3>
            <div className="space-y-2">
              {(editMode ? editedData : problemData).factories.map((factory, index) => (
                <div key={factory.id} className="p-3 bg-green-50 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="font-semibold">{factory.name}</p>
                    <p className="text-sm text-gray-600">{factory.location}</p>
                  </div>
                  <div className="text-right">
                    {editMode ? (
                      <input
                        type="number"
                        value={factory.supply}
                        onChange={(e) => updateFactorySupply(index, e.target.value)}
                        className="w-24 px-2 py-1 text-xl font-bold text-green-600 border rounded text-center"
                        step="1"
                        min="0"
                      />
                    ) : (
                      <p className="text-xl font-bold text-green-600">{factory.supply}</p>
                    )}
                    <p className="text-xs text-gray-500">units</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Warehouses */}
          <div className="card">
            <h3 className="text-lg font-bold mb-4">🏪 Warehouses (Demand) {editMode && '- Editable'}</h3>
            <div className="space-y-2">
              {(editMode ? editedData : problemData).warehouses.map((warehouse, index) => (
                <div key={warehouse.id} className="p-3 bg-blue-50 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="font-semibold">{warehouse.name}</p>
                    <p className="text-sm text-gray-600">{warehouse.location}</p>
                  </div>
                  <div className="text-right">
                    {editMode ? (
                      <input
                        type="number"
                        value={warehouse.demand}
                        onChange={(e) => updateWarehouseDemand(index, e.target.value)}
                        className="w-24 px-2 py-1 text-xl font-bold text-blue-600 border rounded text-center"
                        step="1"
                        min="0"
                      />
                    ) : (
                      <p className="text-xl font-bold text-blue-600">{warehouse.demand}</p>
                    )}
                    <p className="text-xs text-gray-500">units</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Cost Matrix */}
      {(editMode ? editedData : problemData) && (
        <div className="card overflow-x-auto">
          <h3 className="text-lg font-bold mb-4">💰 Transportation Cost Matrix ($ per unit) {editMode && '- Click to Edit'}</h3>
          <p className="text-sm text-gray-600 mb-4">
            {editMode ? 'Edit the cost to ship one unit from each factory to each warehouse' : 'Cost to ship one unit from factory to warehouse'}
          </p>
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th className="table-header">Factory</th>
                  {(editMode ? editedData : problemData).warehouses.map((warehouse) => (
                    <th key={warehouse.id} className="table-header text-center">
                      {warehouse.name.replace('Warehouse ', '')}
                    </th>
                  ))}
                  <th className="table-header text-center bg-green-100">Supply</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {(editMode ? editedData : problemData).factories.map((factory, i) => (
                  <tr key={factory.id} className="hover:bg-gray-50">
                    <td className="table-cell font-medium">{factory.name.replace('Factory ', '')}</td>
                    {(editMode ? editedData : problemData).cost_matrix[i].map((cost, j) => (
                      <td key={j} className="table-cell text-center">
                        {editMode ? (
                          <input
                            type="number"
                            value={cost}
                            onChange={(e) => updateCostMatrix(i, j, e.target.value)}
                            className="w-16 px-2 py-1 border rounded text-center font-semibold"
                            step="1"
                            min="0"
                          />
                        ) : (
                          <span className={`inline-block px-3 py-1 rounded font-semibold ${
                            cost <= 7 ? 'bg-green-100 text-green-800' :
                            cost <= 12 ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            ${cost}
                          </span>
                        )}
                      </td>
                    ))}
                    <td className="table-cell text-center bg-green-50 font-bold">
                      {factory.supply}
                    </td>
                  </tr>
                ))}
                <tr className="bg-blue-50">
                  <td className="table-cell font-bold">Demand</td>
                  {(editMode ? editedData : problemData).warehouses.map((warehouse) => (
                    <td key={warehouse.id} className="table-cell text-center font-bold">
                      {warehouse.demand}
                    </td>
                  ))}
                  <td className="table-cell text-center font-bold">
                    {(editMode ? editedData : problemData).warehouses.reduce((sum, w) => sum + w.demand, 0)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Solve Button */}
      <div className="text-center">
        <button
          onClick={handleSolve}
          disabled={loading || !problemData}
          className="btn-primary"
        >
          {loading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Solving...
            </span>
          ) : (
            '🎯 Optimize Transportation'
          )}
        </button>
      </div>

      {/* Solution */}
      {solution && solution.success && (
        <div className="space-y-6 animate-slide-up">
          {/* Summary */}
          <div className="card bg-green-50 border-l-4 border-green-500">
            <h3 className="text-2xl font-bold text-green-800 mb-2">
              Minimum Cost: ${solution.total_cost?.toLocaleString()}
            </h3>
            <p className="text-green-700">Optimal distribution plan found using {solution.method}!</p>
            {solution.vam_optimality_gap !== undefined && (
              <p className="text-sm text-green-600 mt-1">
                VAM heuristic was {solution.vam_optimality_gap.toFixed(2)}% from optimal
              </p>
            )}
          </div>

          {/* Shipment Matrix */}
          <div className="card overflow-x-auto">
            <h3 className="text-xl font-bold mb-4">📦 Optimal Shipment Plan</h3>
            <p className="text-sm text-gray-600 mb-4">Quantity to ship from each factory to each warehouse</p>
            <div className="table-container">
              <table className="table">
                <thead>
                  <tr>
                    <th className="table-header">Factory</th>
                    {solution.warehouse_names.map((warehouse) => (
                      <th key={warehouse} className="table-header text-center">
                        {warehouse.replace('Warehouse ', '')}
                      </th>
                    ))}
                    <th className="table-header text-center bg-green-100">Shipped</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {solution.factory_names.map((factory, i) => (
                    <tr key={factory} className="hover:bg-gray-50">
                      <td className="table-cell font-medium">{factory.replace('Factory ', '')}</td>
                      {solution.shipments[i].map((quantity, j) => (
                        <td key={j} className="table-cell text-center">
                          {quantity > 0 ? (
                            <span className="inline-block px-3 py-1 rounded font-bold bg-primary-100 text-primary-800">
                              {quantity}
                            </span>
                          ) : (
                            <span className="text-gray-300">-</span>
                          )}
                        </td>
                      ))}
                      <td className="table-cell text-center bg-green-50 font-bold">
                        {solution.shipments[i].reduce((sum, val) => sum + val, 0).toFixed(0)}
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-blue-50">
                    <td className="table-cell font-bold">Received</td>
                    {solution.warehouse_names.map((_, j) => (
                      <td key={j} className="table-cell text-center font-bold">
                        {solution.factory_names.reduce((sum, _, i) => sum + solution.shipments[i][j], 0).toFixed(0)}
                      </td>
                    ))}
                    <td className="table-cell text-center font-bold">
                      {solution.total_supply}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Shipment Details */}
          <div className="card">
            <h3 className="text-xl font-bold mb-4">📋 Detailed Shipments</h3>
            <div className="space-y-3">
              {solution.shipment_details?.map((shipment, index) => (
                <div key={index} className="p-4 bg-gray-50 rounded-lg flex items-center justify-between hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="text-center px-3 py-2 bg-green-500 text-white rounded-lg">
                      <p className="text-xs">From</p>
                      <p className="font-bold">{shipment.factory_name.replace('Factory ', '')}</p>
                    </div>
                    <div className="text-2xl text-gray-400">→</div>
                    <div className="text-center px-3 py-2 bg-blue-500 text-white rounded-lg">
                      <p className="text-xs">To</p>
                      <p className="font-bold">{shipment.warehouse_name.replace('Warehouse ', '')}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6">
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Quantity</p>
                      <p className="text-xl font-bold text-primary-600">{shipment.quantity}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Unit Cost</p>
                      <p className="text-xl font-bold text-gray-700">${shipment.unit_cost}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Total</p>
                      <p className="text-xl font-bold text-green-600">${shipment.total_cost.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Utilization */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Factory Utilization */}
            <div className="card">
              <h3 className="text-lg font-bold mb-4">Factory Utilization</h3>
              <div className="space-y-3">
                {solution.factory_utilization?.map((factory) => (
                  <div key={factory.factory}>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">{factory.factory}</span>
                      <span className="text-sm text-gray-600">
                        {factory.shipped} / {factory.capacity} ({factory.utilization}%)
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div
                        className="bg-green-500 h-3 rounded-full transition-all duration-500"
                        style={{ width: `${factory.utilization}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Warehouse Fulfillment */}
            <div className="card">
              <h3 className="text-lg font-bold mb-4">Warehouse Demand Fulfillment</h3>
              <div className="space-y-3">
                {solution.warehouse_received?.map((warehouse) => (
                  <div key={warehouse.warehouse}>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">{warehouse.warehouse}</span>
                      <span className="text-sm text-gray-600">
                        {warehouse.received} / {warehouse.demand} ({warehouse.fulfillment}%)
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div
                        className="bg-blue-500 h-3 rounded-full transition-all duration-500"
                        style={{ width: `${warehouse.fulfillment}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Algorithm Info */}
          <div className="card bg-green-50">
            <h3 className="text-lg font-bold mb-2">🔬 Algorithm Details</h3>
            <div className="space-y-2 text-sm">
              <p><strong>Method:</strong> {solution.method}</p>
              <p><strong>Status:</strong> {solution.message}</p>
              <p><strong>Problem Size:</strong> 4 factories × 5 warehouses = 20 routes</p>
              <p><strong>Total Supply:</strong> {solution.total_supply} units</p>
              <p><strong>Total Demand:</strong> {solution.total_demand} units</p>
              <p><strong>Balance:</strong> {solution.total_supply === solution.total_demand ? '✓ Balanced' : '✗ Unbalanced'}</p>
            </div>
            
            {solution.vam_steps && solution.vam_steps.length > 0 && (
              <div className="mt-4">
                <button
                  onClick={() => setShowSteps(!showSteps)}
                  className="btn-primary w-full"
                >
                  {showSteps ? '🔼 Hide Algorithm Steps' : '🔽 Show Algorithm Steps (VAM)'}
                </button>
              </div>
            )}
          </div>

          {/* VAM Steps Visualization */}
          {showSteps && solution.vam_steps && (
            <div className="card bg-gradient-to-br from-green-50 to-emerald-50">
              <h3 className="text-2xl font-bold mb-4 text-green-800">📊 Vogel's Approximation Method Steps</h3>
              <p className="text-sm text-gray-700 mb-6">
                VAM is a heuristic method that provides near-optimal solutions by allocating shipments 
                based on penalty costs (difference between the two lowest costs in each row/column).
              </p>
              
              <div className="space-y-6">
                {solution.vam_steps.map((step, index) => (
                  <div key={index} className="bg-white p-6 rounded-lg shadow-md border-l-4 border-green-500">
                    <div className="mb-3">
                      <h4 className="text-xl font-bold text-green-700">
                        {step.iteration === 0 ? 'Initial State' : `Iteration ${step.iteration}`}
                      </h4>
                      <p className="text-gray-700 mt-2">{step.description}</p>
                    </div>
                    
                    {step.iteration > 0 && (
                      <>
                        {/* Penalty Information */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          {step.row_penalties && Object.keys(step.row_penalties).length > 0 && (
                            <div className="p-3 bg-blue-50 rounded">
                              <p className="text-sm font-semibold mb-2">Row Penalties:</p>
                              {Object.entries(step.row_penalties).map(([row, penalty]) => (
                                <p key={row} className="text-sm">
                                  {solution.factory_names[parseInt(row)]?.replace('Factory ', '')}: 
                                  <span className={`ml-2 font-bold ${
                                    step.penalty_type === 'row' && parseInt(row) === step.selected_row
                                      ? 'text-green-700' : 'text-gray-600'
                                  }`}>
                                    {penalty.toFixed(1)}
                                    {step.penalty_type === 'row' && parseInt(row) === step.selected_row && ' ✓'}
                                  </span>
                                </p>
                              ))}
                            </div>
                          )}
                          
                          {step.col_penalties && Object.keys(step.col_penalties).length > 0 && (
                            <div className="p-3 bg-purple-50 rounded">
                              <p className="text-sm font-semibold mb-2">Column Penalties:</p>
                              {Object.entries(step.col_penalties).map(([col, penalty]) => (
                                <p key={col} className="text-sm">
                                  {solution.warehouse_names[parseInt(col)]?.replace('Warehouse ', '')}: 
                                  <span className={`ml-2 font-bold ${
                                    step.penalty_type === 'column' && parseInt(col) === step.selected_col
                                      ? 'text-purple-700' : 'text-gray-600'
                                  }`}>
                                    {penalty.toFixed(1)}
                                    {step.penalty_type === 'column' && parseInt(col) === step.selected_col && ' ✓'}
                                  </span>
                                </p>
                              ))}
                            </div>
                          )}
                        </div>
                        
                        {/* Allocation Info */}
                        <div className="p-4 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg">
                          <p className="text-sm font-semibold text-green-800 mb-2">
                            Selected Allocation (Highest Penalty: {step.penalty_value?.toFixed(1)})
                          </p>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                            <div>
                              <p className="text-gray-600">From</p>
                              <p className="font-bold">{step.factory_name?.replace('Factory ', '')}</p>
                            </div>
                            <div>
                              <p className="text-gray-600">To</p>
                              <p className="font-bold">{step.warehouse_name?.replace('Warehouse ', '')}</p>
                            </div>
                            <div>
                              <p className="text-gray-600">Quantity</p>
                              <p className="font-bold text-blue-700">{step.allocation} units</p>
                            </div>
                            <div>
                              <p className="text-gray-600">Cost</p>
                              <p className="font-bold text-green-700">${step.total_cost_this_allocation?.toFixed(0)}</p>
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                    
                    {/* Current Shipments Matrix */}
                    {step.shipments && (
                      <div className="mt-4 overflow-x-auto">
                        <p className="text-sm font-semibold mb-2">Current Shipment Allocation:</p>
                        <table className="min-w-full text-sm border-collapse">
                          <thead>
                            <tr className="bg-green-100">
                              <th className="border px-2 py-1 font-semibold">Factory</th>
                              {solution.warehouse_names.map((wh, i) => (
                                <th key={i} className="border px-2 py-1 font-semibold">
                                  {wh.replace('Warehouse ', '')}
                                </th>
                              ))}
                              <th className="border px-2 py-1 font-semibold bg-blue-100">Left</th>
                            </tr>
                          </thead>
                          <tbody>
                            {step.shipments.map((row, i) => (
                              <tr key={i} className={!step.active_rows?.includes(i) ? 'bg-gray-100' : 'hover:bg-gray-50'}>
                                <td className="border px-2 py-1 font-medium">
                                  {solution.factory_names[i]?.replace('Factory ', '')}
                                </td>
                                {row.map((cell, j) => {
                                  const isNewAllocation = step.iteration > 0 && 
                                                         i === step.selected_row && 
                                                         j === step.selected_col;
                                  return (
                                    <td 
                                      key={j} 
                                      className={`border px-2 py-1 text-center ${
                                        isNewAllocation ? 'bg-yellow-200 font-bold' :
                                        cell > 0 ? 'bg-green-50 font-semibold' : ''
                                      }`}
                                    >
                                      {cell > 0 ? cell : '-'}
                                    </td>
                                  );
                                })}
                                <td className="border px-2 py-1 text-center bg-blue-50 font-semibold">
                                  {step.supply_left?.[i] || 0}
                                </td>
                              </tr>
                            ))}
                            <tr className="bg-blue-100">
                              <td className="border px-2 py-1 font-bold">Demand Left</td>
                              {step.demand_left?.map((demand, j) => (
                                <td key={j} className="border px-2 py-1 text-center font-semibold">
                                  {demand}
                                </td>
                              ))}
                              <td className="border px-2 py-1"></td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    )}
                    
                    {step.note && (
                      <div className="mt-3 p-3 bg-gray-50 rounded border-l-2 border-gray-400">
                        <p className="text-sm text-gray-700">
                          <strong>Note:</strong> {step.note}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              
              <div className="mt-6 p-4 bg-green-50 rounded-lg border-2 border-green-300">
                <h4 className="font-bold text-green-800 mb-2">✅ VAM Solution Complete</h4>
                <p className="text-sm text-gray-700">
                  Vogel's Approximation Method has completed with a total transportation cost of 
                  <strong className="text-green-700"> ${solution.total_cost?.toLocaleString()}</strong>.
                  {solution.vam_optimality_gap !== undefined && (
                    <> This solution is <strong>{solution.vam_optimality_gap.toFixed(2)}%</strong> from the optimal LP solution.</>
                  )}
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default TransportationProblem;
