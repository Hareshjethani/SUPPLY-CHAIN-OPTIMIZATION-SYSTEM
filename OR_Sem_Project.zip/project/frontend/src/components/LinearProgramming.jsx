import React, { useState, useEffect } from 'react';
import { lpAPI } from '../api';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

function LinearProgramming() {
  const [problemData, setProblemData] = useState(null);
  const [solution, setSolution] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showSteps, setShowSteps] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editedData, setEditedData] = useState(null);

  useEffect(() => {
    loadProblemData();
  }, []);

  const loadProblemData = async () => {
    try {
      const response = await lpAPI.getData();
      setProblemData(response.data);
      setEditedData(JSON.parse(JSON.stringify(response.data)));
    } catch (err) {
      setError('Failed to load problem data');
      console.error(err);
    }
  };

  const handleSolve = async () => {
    setLoading(true);
    setError(null);
    setSolution(null);
    try {
      const dataToSolve = editMode ? editedData : problemData;
      const response = await lpAPI.solve(dataToSolve);
      setSolution(response.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to solve problem');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEditToggle = () => {
    if (!editMode) {
      setEditedData(JSON.parse(JSON.stringify(problemData)));
    }
    setEditMode(!editMode);
    setSolution(null);
  };

  const handleReset = () => {
    loadProblemData();
    setSolution(null);
    setEditMode(false);
  };

  const updateProductProfit = (index, value) => {
    const newData = { ...editedData };
    newData.products[index].profit = parseFloat(value) || 0;
    setEditedData(newData);
  };

  const updateProductResource = (productIndex, resourceName, value) => {
    const newData = { ...editedData };
    newData.products[productIndex].resources[resourceName] = parseFloat(value) || 0;
    setEditedData(newData);
  };

  const updateResourceAvailable = (index, value) => {
    const newData = { ...editedData };
    newData.resources[index].available = parseFloat(value) || 0;
    setEditedData(newData);
  };

  const updateMarketLimit = (productName, value) => {
    const newData = { ...editedData };
    newData.market_limits[productName] = parseFloat(value) || 0;
    setEditedData(newData);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card bg-gradient-to-r from-blue-500 to-blue-600 text-white">
        <h2 className="text-3xl font-bold mb-2">📈 Linear Programming</h2>
        <p className="text-blue-100">
          Maximize profit by optimizing production quantities with resource constraints
        </p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">{error}</p>
        </div>
      )}

      {/* Edit/Reset Controls */}
      {problemData && (
        <div className="card bg-gradient-to-r from-indigo-50 to-blue-50">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold text-gray-800">
                {editMode ? '✏️ Edit Mode: Modify Problem Parameters' : '📋 Using Default Problem Data'}
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                {editMode ? 'Change values below and click Solve to see results' : 'Click Edit to customize the problem'}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleEditToggle}
                className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                  editMode 
                    ? 'bg-gray-500 text-white hover:bg-gray-600' 
                    : 'bg-blue-500 text-white hover:bg-blue-600'
                }`}
              >
                {editMode ? '📖 View Mode' : '✏️ Edit Problem'}
              </button>
              {editMode && (
                <button
                  onClick={handleReset}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 transition-colors"
                >
                  🔄 Reset to Default
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Problem Statement */}
      <div className="card">
        <h3 className="text-xl font-bold mb-4">Problem Statement</h3>
        <div className="bg-gray-50 p-4 rounded-lg">
          <p className="text-gray-700 mb-2">
            <strong>Objective:</strong> Maximize total profit from producing electronic components
          </p>
          {(editMode ? editedData : problemData) && (
            <div className="mt-4 space-y-2">
              <p className="font-semibold">Products ({(editMode ? editedData : problemData).products?.length || 0}):</p>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
                {(editMode ? editedData : problemData).products?.map((product, index) => (
                  <div key={product.name} className="text-sm bg-white p-2 rounded shadow-sm">
                    <span className="font-semibold">{product.name}</span>: 
                    {editMode ? (
                      <input
                        type="number"
                        value={product.profit}
                        onChange={(e) => updateProductProfit(index, e.target.value)}
                        className="w-full mt-1 px-2 py-1 border rounded text-center"
                        step="0.01"
                      />
                    ) : (
                      <span> ${product.profit}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Input Data */}
      {(editMode ? editedData : problemData) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Resources */}
          <div className="card">
            <h3 className="text-lg font-bold mb-4">Resource Constraints ({(editMode ? editedData : problemData).resources?.length || 0})</h3>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {(editMode ? editedData : problemData).resources?.map((resource, index) => (
                <div key={resource.name} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="text-sm font-medium">{resource.name}</span>
                  {editMode ? (
                    <input
                      type="number"
                      value={resource.available}
                      onChange={(e) => updateResourceAvailable(index, e.target.value)}
                      className="w-24 px-2 py-1 border rounded text-center"
                      step="1"
                    />
                  ) : (
                    <span className="text-primary-600 font-semibold text-sm">
                      {resource.available} {resource.unit}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Market Limits */}
          <div className="card">
            <h3 className="text-lg font-bold mb-4">Market Demand Limits</h3>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {(editMode ? editedData : problemData).market_limits && Object.entries((editMode ? editedData : problemData).market_limits).map(([product, limit]) => (
                <div key={product} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="text-sm font-medium">{product}</span>
                  {editMode ? (
                    <input
                      type="number"
                      value={limit}
                      onChange={(e) => updateMarketLimit(product, e.target.value)}
                      className="w-24 px-2 py-1 border rounded text-center"
                      step="1"
                    />
                  ) : (
                    <span className="text-green-600 font-semibold text-sm">{limit} units</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Resource Requirements Matrix (Edit Mode) */}
      {editMode && editedData && (
        <div className="card">
          <h3 className="text-lg font-bold mb-4">📊 Resource Requirements per Unit</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-blue-100">
                  <th className="border px-3 py-2 text-left">Product</th>
                  {editedData.resources.map(resource => (
                    <th key={resource.name} className="border px-3 py-2 text-center">{resource.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {editedData.products.map((product, pIndex) => (
                  <tr key={product.name} className="hover:bg-gray-50">
                    <td className="border px-3 py-2 font-medium">{product.name}</td>
                    {editedData.resources.map(resource => (
                      <td key={resource.name} className="border px-3 py-2 text-center">
                        <input
                          type="number"
                          value={product.resources[resource.name]}
                          onChange={(e) => updateProductResource(pIndex, resource.name, e.target.value)}
                          className="w-20 px-2 py-1 border rounded text-center"
                          step="0.1"
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Solve Button */}
      <div className="card text-center">
        <button
          onClick={handleSolve}
          disabled={loading}
          className="btn-primary text-lg px-8 py-3 disabled:opacity-50"
        >
          {loading ? 'Solving...' : '🚀 Solve Problem'}
        </button>
      </div>

      {/* Solution */}
      {solution && solution.success && (
        <div className="space-y-6">
          {/* Optimal Solution Header */}
          <div className="card bg-gradient-to-r from-green-500 to-green-600 text-white">
            <h3 className="text-2xl font-bold mb-2">✅ Optimal Solution Found</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
              <div>
                <p className="text-green-100 text-sm">Maximum Profit</p>
                <p className="text-3xl font-bold">${solution.max_profit?.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-green-100 text-sm">Iterations</p>
                <p className="text-3xl font-bold">{solution.iterations || 'N/A'}</p>
              </div>
              <div>
                <p className="text-green-100 text-sm">Status</p>
                <p className="text-lg font-semibold">{solution.message}</p>
              </div>
            </div>
          </div>

          {/* Production Plan */}
          <div className="card">
            <h3 className="text-xl font-bold mb-4">📦 Optimal Production Plan</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="px-4 py-2 text-left">Product</th>
                    <th className="px-4 py-2 text-right">Quantity</th>
                    <th className="px-4 py-2 text-right">Profit/Unit</th>
                    <th className="px-4 py-2 text-right">Total Profit</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(solution.optimal_production || {}).map(([product, quantity]) => {
                    const productData = problemData?.products?.find(p => p.name === product);
                    const profit = productData?.profit || 0;
                    return (
                      <tr key={product} className={quantity > 0 ? 'bg-green-50' : ''}>
                        <td className="border-t px-4 py-2 font-medium">{product}</td>
                        <td className="border-t px-4 py-2 text-right">{quantity.toFixed(2)}</td>
                        <td className="border-t px-4 py-2 text-right">${profit}</td>
                        <td className="border-t px-4 py-2 text-right font-semibold">
                          ${(quantity * profit).toFixed(2)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Production Chart */}
            <div className="card">
              <h3 className="text-xl font-bold mb-4">Production Quantities</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={Object.entries(solution.optimal_production || {}).map(([name, value]) => ({
                  name,
                  quantity: value
                }))}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="quantity" fill="#0ea5e9" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Resource Utilization */}
            <div className="card">
              <h3 className="text-xl font-bold mb-4">Resource Utilization</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={Object.entries(solution.resource_utilization || {}).map(([name, data]) => ({
                  name,
                  percentage: data.percentage
                }))}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Bar dataKey="percentage" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Market Utilization Radar */}
          <div className="card">
            <h3 className="text-xl font-bold mb-4">Market Demand Utilization</h3>
            <ResponsiveContainer width="100%" height={400}>
              <RadarChart data={Object.entries(solution.market_utilization || {}).map(([name, util]) => ({
                subject: name,
                percentage: util.percentage,
                fullMark: 100
              }))}>
                <PolarGrid />
                <PolarAngleAxis dataKey="subject" />
                <PolarRadiusAxis angle={90} domain={[0, 100]} />
                <Radar name="Utilization %" dataKey="percentage" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.6} />
                <Tooltip />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          {/* Slack Resources */}
          <div className="card">
            <h3 className="text-xl font-bold mb-4">Unused Resources (Slack)</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {Object.entries(solution.slack || {}).map(([resource, value]) => (
                <div key={resource} className="p-4 bg-gray-50 rounded-lg text-center">
                  <p className="text-xs text-gray-600 mb-1">{resource}</p>
                  <p className="text-xl font-bold text-gray-700">{value.toFixed(2)}</p>
                  <p className="text-xs text-gray-500">units</p>
                </div>
              ))}
            </div>
          </div>

          {/* Algorithm Details */}
          <div className="card bg-blue-50">
            <h3 className="text-lg font-bold mb-2">🔬 Algorithm Details</h3>
            <div className="space-y-2 text-sm">
              <p><strong>Method:</strong> Simplex Algorithm (HiGHS solver)</p>
              <p><strong>Status:</strong> {solution.message}</p>
              <p><strong>Iterations:</strong> {solution.iterations}</p>
              <p><strong>Decision Variables:</strong> {problemData?.products?.length || 0}</p>
              <p><strong>Constraints:</strong> {(problemData?.resources?.length || 0) + Object.keys(problemData?.market_limits || {}).length}</p>
            </div>
            
            {solution.simplex_steps && solution.simplex_steps.length > 0 && (
              <div className="mt-4">
                <button
                  onClick={() => setShowSteps(!showSteps)}
                  className="btn-primary w-full"
                >
                  {showSteps ? '🔼 Hide Algorithm Steps' : '🔽 Show Algorithm Steps (Simplex Tableau)'}
                </button>
              </div>
            )}
          </div>

          {/* Simplex Steps Visualization */}
          {showSteps && solution.simplex_steps && (
            <div className="card bg-gradient-to-br from-blue-50 to-indigo-50">
              <h3 className="text-2xl font-bold mb-4 text-blue-800">📊 Simplex Algorithm Steps</h3>
              <p className="text-sm text-gray-700 mb-6">
                The Simplex Method iteratively moves from one corner point of the feasible region to another, 
                improving the objective function value at each step until the optimal solution is reached.
              </p>
              
              <div className="space-y-6">
                {solution.simplex_steps.map((step, index) => (
                  <div key={index} className="bg-white p-6 rounded-lg shadow-md border-l-4 border-blue-500">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-xl font-bold text-blue-700">
                        Iteration {step.iteration}
                      </h4>
                      {step.objective_value !== undefined && (
                        <div className="text-right">
                          <p className="text-sm text-gray-600">Objective Value</p>
                          <p className="text-2xl font-bold text-green-600">
                            ${Math.abs(step.objective_value).toFixed(2)}
                          </p>
                        </div>
                      )}
                    </div>
                    
                    <p className="text-gray-700 mb-4">{step.description}</p>
                    
                    {step.tableau && (
                      <div className="overflow-x-auto">
                        <table className="min-w-full text-sm border-collapse">
                          <thead>
                            <tr className="bg-blue-100">
                              <th className="border px-3 py-2 font-semibold">Basis</th>
                              {step.column_headers?.map((header, i) => (
                                <th key={i} className="border px-3 py-2 font-semibold">{header}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {step.tableau.map((row, i) => (
                              <tr key={i} className={i === 0 ? 'bg-yellow-50 font-semibold' : 'hover:bg-gray-50'}>
                                <td className="border px-3 py-2 font-medium">
                                  {step.row_headers?.[i] || ''}
                                </td>
                                {row.map((cell, j) => (
                                  <td key={j} className="border px-3 py-2 text-center">
                                    {cell.toFixed(2)}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                    
                    {step.basis && (
                      <div className="mt-3 p-3 bg-blue-50 rounded">
                        <p className="text-sm">
                          <strong>Basic Variables:</strong> {step.basis.join(', ')}
                        </p>
                      </div>
                    )}
                    
                    {step.entering_var && (
                      <div className="mt-3 p-3 bg-green-50 rounded">
                        <p className="text-sm">
                          <strong>Entering Variable:</strong> {step.entering_var}
                        </p>
                        <p className="text-sm">
                          <strong>Leaving Variable:</strong> {step.leaving_var}
                        </p>
                      </div>
                    )}
                    
                    {step.note && (
                      <div className="mt-3 p-3 bg-gray-50 rounded border-l-2 border-gray-400">
                        <p className="text-sm text-gray-700">
                          <strong>Note:</strong> {step.note}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              
              <div className="mt-6 p-4 bg-green-50 rounded-lg border-2 border-green-300">
                <h4 className="font-bold text-green-800 mb-2">✅ Final Optimal Solution</h4>
                <p className="text-sm text-gray-700">
                  The algorithm has converged to the optimal solution with a maximum profit of 
                  <strong className="text-green-700"> ${solution.max_profit?.toLocaleString()}</strong>.
                  All coefficients in the objective row are non-negative, confirming optimality.
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default LinearProgramming;
