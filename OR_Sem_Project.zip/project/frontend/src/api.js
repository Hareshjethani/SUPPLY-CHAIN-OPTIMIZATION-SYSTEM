import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Linear Programming API
export const lpAPI = {
  getData: () => api.get('/api/lp/data'),
  solve: (data = null) => api.post('/api/lp/solve', data),
  getReport: (data = null) => api.post('/api/lp/report', data),
};

// Assignment Problem API
export const assignmentAPI = {
  getData: () => api.get('/api/assignment/data'),
  solve: (data = null) => api.post('/api/assignment/solve', data),
  getReport: (data = null) => api.post('/api/assignment/report', data),
};

// Transportation Problem API
export const transportationAPI = {
  getData: () => api.get('/api/transportation/data'),
  solve: (data = null) => api.post('/api/transportation/solve', data),
  getReport: (data = null) => api.post('/api/transportation/report', data),
};

// Combined API
export const solveAll = () => api.post('/api/solve-all');

export default api;
