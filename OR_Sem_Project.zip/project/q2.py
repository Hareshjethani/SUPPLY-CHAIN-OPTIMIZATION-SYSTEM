"""
Question 2: Assignment Problem - Task-Worker Allocation
========================================================

Problem: Assign 5 specialized assembly tasks to 5 workers to minimize total
completion time. Each worker must be assigned exactly one task, and each task
must be assigned to exactly one worker.

Method: Hungarian Algorithm using scipy.optimize.linear_sum_assignment
Reference: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.linear_sum_assignment.html

Author: TechParts Inc. Operations Research Team
Date: December 2025
"""

import numpy as np
from scipy.optimize import linear_sum_assignment
import json
from typing import Dict, List, Tuple, Any


class AssignmentProblemSolver:
    """
    Solves the Assignment Problem using the Hungarian Algorithm.
    
    The Hungarian algorithm finds the optimal assignment of n tasks to n workers
    to minimize the total cost (or time). Time complexity: O(n³)
    """
    
    def __init__(self, problem_data: Dict[str, Any]):
        """
        Initialize the Assignment Problem solver with problem data.
        
        Args:
            problem_data: Dictionary containing:
                - workers: List of worker details
                - tasks: List of task details
                - cost_matrix: n×n matrix of completion times
        """
        self.problem_data = problem_data
        self.workers = problem_data['workers']
        self.tasks = problem_data['tasks']
        self.cost_matrix = np.array(problem_data['cost_matrix'])
        
        # Validate matrix dimensions
        n_workers = len(self.workers)
        n_tasks = len(self.tasks)
        
        if n_workers != n_tasks:
            raise ValueError(f"Number of workers ({n_workers}) must equal "
                           f"number of tasks ({n_tasks})")
        
        if self.cost_matrix.shape != (n_workers, n_tasks):
            raise ValueError(f"Cost matrix shape {self.cost_matrix.shape} "
                           f"doesn't match workers×tasks ({n_workers}×{n_tasks})")
    
    def solve(self) -> Dict[str, Any]:
        """
        Solve the assignment problem using the Hungarian Algorithm.
        
        The Hungarian algorithm works by:
        1. Row reduction: Subtract minimum from each row
        2. Column reduction: Subtract minimum from each column
        3. Cover zeros with minimum lines
        4. If covers < n, adjust matrix and repeat
        5. Find optimal assignment from zero positions
        
        Returns:
            Dictionary containing:
                - success: Whether optimization succeeded
                - assignments: List of worker-task pairs
                - total_time: Minimum total completion time
                - assignment_details: Detailed information for each assignment
                - cost_matrix: Original cost matrix for reference
                - algorithm_steps: Step-by-step Hungarian algorithm visualization
        """
        try:
            # Generate algorithm steps for visualization
            algorithm_steps = self._generate_algorithm_steps()
            
            # Solve using Hungarian algorithm
            # Returns row indices and column indices of optimal assignment
            row_indices, col_indices = linear_sum_assignment(self.cost_matrix)
            
            # Calculate total cost
            total_time = self.cost_matrix[row_indices, col_indices].sum()
            
            # Build assignment details
            assignments = []
            assignment_details = []
            
            for worker_idx, task_idx in zip(row_indices, col_indices):
                worker = self.workers[worker_idx]
                task = self.tasks[task_idx]
                time = self.cost_matrix[worker_idx, task_idx]
                
                assignment = {
                    'worker': worker['name'],
                    'task': task['name'],
                    'time': float(time)
                }
                
                detail = {
                    'worker_id': int(worker_idx),
                    'worker_name': worker['name'],
                    'worker_experience': worker['experience'],
                    'task_id': int(task_idx),
                    'task_name': task['name'],
                    'task_description': task['description'],
                    'completion_time': float(time),
                    'efficiency_rank': self._calculate_efficiency_rank(worker_idx, task_idx)
                }
                
                assignments.append(assignment)
                assignment_details.append(detail)
            
            # Calculate statistics
            avg_time = float(np.mean([d['completion_time'] for d in assignment_details]))
            max_time = float(np.max([d['completion_time'] for d in assignment_details]))
            min_time = float(np.min([d['completion_time'] for d in assignment_details]))
            
            return {
                'success': True,
                'assignments': assignments,
                'total_time': float(total_time),
                'average_time': avg_time,
                'max_time': max_time,
                'min_time': min_time,
                'assignment_details': assignment_details,
                'cost_matrix': self.cost_matrix.tolist(),
                'worker_names': [w['name'] for w in self.workers],
                'task_names': [t['name'] for t in self.tasks],
                'message': 'Assignment optimization successful',
                'algorithm_steps': algorithm_steps
            }
            
        except Exception as e:
            return {
                'success': False,
                'message': f"Assignment optimization failed: {str(e)}",
                'assignments': None,
                'total_time': None
            }
    
    def _calculate_efficiency_rank(self, worker_idx: int, task_idx: int) -> str:
        """
        Calculate how efficient this assignment is compared to alternatives.
        
        Args:
            worker_idx: Index of the worker
            task_idx: Index of the task
            
        Returns:
            Rank string (Optimal, Good, Average, Poor)
        """
        # Get the assigned time
        assigned_time = self.cost_matrix[worker_idx, task_idx]
        
        # Get min and max possible times for this task
        task_times = self.cost_matrix[:, task_idx]
        min_time = task_times.min()
        max_time = task_times.max()
        
        if assigned_time == min_time:
            return "Optimal"
        elif assigned_time <= min_time + (max_time - min_time) * 0.33:
            return "Good"
        elif assigned_time <= min_time + (max_time - min_time) * 0.66:
            return "Average"
        else:
            return "Below Average"
    
    def solve_with_visualization(self) -> Dict[str, Any]:
        """
        Solve and include visualization data for the Hungarian algorithm steps.
        
        Returns:
            Solution with additional visualization data
        """
        solution = self.solve()
        
        if not solution['success']:
            return solution
        
        # Add step-by-step algorithm visualization
        steps = self._generate_algorithm_steps()
        solution['algorithm_steps'] = steps
        
        return solution
    
    def _generate_algorithm_steps(self) -> List[Dict[str, Any]]:
        """
        Generate step-by-step visualization of the Hungarian algorithm.
        
        Returns:
            List of steps with matrices at each stage
        """
        steps = []
        
        # Step 1: Original matrix
        steps.append({
            'step': 1,
            'title': 'Original Cost Matrix',
            'description': 'Initial completion times (in hours) for each worker-task pair',
            'matrix': self.cost_matrix.tolist(),
            'worker_names': [w['name'] for w in self.workers],
            'task_names': [t['name'] for t in self.tasks],
            'note': 'Our goal is to minimize the total completion time by optimally assigning workers to tasks'
        })
        
        # Step 2: Row reduction
        row_mins = self.cost_matrix.min(axis=1, keepdims=True)
        row_reduced = self.cost_matrix - row_mins
        steps.append({
            'step': 2,
            'title': 'Row Reduction',
            'description': 'Subtract the minimum value from each row',
            'matrix': row_reduced.tolist(),
            'worker_names': [w['name'] for w in self.workers],
            'task_names': [t['name'] for t in self.tasks],
            'row_mins': row_mins.flatten().tolist(),
            'note': 'Each row now has at least one zero, representing the best task for each worker'
        })
        
        # Step 3: Column reduction
        col_mins = row_reduced.min(axis=0, keepdims=True)
        col_reduced = row_reduced - col_mins
        steps.append({
            'step': 3,
            'title': 'Column Reduction',
            'description': 'Subtract the minimum value from each column of the row-reduced matrix',
            'matrix': col_reduced.tolist(),
            'worker_names': [w['name'] for w in self.workers],
            'task_names': [t['name'] for t in self.tasks],
            'col_mins': col_mins.flatten().tolist(),
            'note': 'This reduced matrix has zeros that represent potential optimal assignments'
        })
        
        # Step 4: Find zero positions
        zero_positions = np.argwhere(col_reduced == 0).tolist()
        steps.append({
            'step': 4,
            'title': 'Identify Zero Positions',
            'description': 'Locate all zero entries in the reduced matrix',
            'matrix': col_reduced.tolist(),
            'worker_names': [w['name'] for w in self.workers],
            'task_names': [t['name'] for t in self.tasks],
            'zero_positions': zero_positions,
            'note': f'Found {len(zero_positions)} zero positions. The optimal assignment will use {len(self.workers)} of these.'
        })
        
        # Step 5: Optimal assignment (using scipy's result)
        row_indices, col_indices = linear_sum_assignment(self.cost_matrix)
        assignment_matrix = np.zeros_like(self.cost_matrix)
        for i, j in zip(row_indices, col_indices):
            assignment_matrix[i, j] = 1
        
        steps.append({
            'step': 5,
            'title': 'Optimal Assignment',
            'description': 'Final optimal worker-task assignments (marked with ✓)',
            'matrix': col_reduced.tolist(),
            'assignment_matrix': assignment_matrix.tolist(),
            'worker_names': [w['name'] for w in self.workers],
            'task_names': [t['name'] for t in self.tasks],
            'assignments': [(int(i), int(j)) for i, j in zip(row_indices, col_indices)],
            'total_cost': float(self.cost_matrix[row_indices, col_indices].sum()),
            'note': 'These assignments minimize the total completion time'
        })
        
        return steps
    
    def generate_report(self, solution: Dict[str, Any]) -> str:
        """
        Generate a detailed text report of the assignment results.
        
        Args:
            solution: Solution dictionary from solve()
            
        Returns:
            Formatted report string
        """
        if not solution['success']:
            return f"ASSIGNMENT FAILED\n{solution['message']}"
        
        report = []
        report.append("=" * 80)
        report.append("ASSIGNMENT PROBLEM OPTIMIZATION REPORT")
        report.append("TechParts Inc. - Task-Worker Allocation")
        report.append("=" * 80)
        report.append("")
        
        report.append("OPTIMAL ASSIGNMENTS:")
        report.append("-" * 80)
        for detail in solution['assignment_details']:
            report.append(f"  {detail['worker_name']:15s} ({detail['worker_experience']:12s}) → "
                         f"{detail['task_name']:30s}")
            report.append(f"  {'':15s} Time: {detail['completion_time']:5.1f} hours  "
                         f"Efficiency: {detail['efficiency_rank']}")
            report.append("")
        
        report.append("SUMMARY STATISTICS:")
        report.append("-" * 80)
        report.append(f"  Total Completion Time    : {solution['total_time']:6.1f} hours")
        report.append(f"  Average Time per Task    : {solution['average_time']:6.1f} hours")
        report.append(f"  Longest Task             : {solution['max_time']:6.1f} hours")
        report.append(f"  Shortest Task            : {solution['min_time']:6.1f} hours")
        report.append("")
        
        report.append("COST MATRIX (Completion Times in Hours):")
        report.append("-" * 80)
        
        # Header
        header = "Worker      |"
        for task in solution['task_names']:
            header += f" {task[:12]:^12s} |"
        report.append(header)
        report.append("-" * 80)
        
        # Matrix rows
        for i, worker_name in enumerate(solution['worker_names']):
            row = f"{worker_name:12s}|"
            for j, time in enumerate(solution['cost_matrix'][i]):
                # Highlight optimal assignments
                is_assigned = any(
                    d['worker_name'] == worker_name and d['task_id'] == j
                    for d in solution['assignment_details']
                )
                if is_assigned:
                    row += f" [{time:5.1f}]     |"
                else:
                    row += f"  {time:5.1f}      |"
            report.append(row)
        
        report.append("")
        report.append("Note: Optimal assignments are shown in [brackets]")
        report.append("=" * 80)
        
        return "\n".join(report)
    
    def compare_with_alternatives(self, solution: Dict[str, Any]) -> Dict[str, Any]:
        """
        Compare the optimal solution with alternative assignment strategies.
        
        Args:
            solution: Optimal solution from solve()
            
        Returns:
            Comparison data
        """
        comparisons = {
            'optimal': solution['total_time']
        }
        
        # Random assignment (average of multiple random trials)
        random_times = []
        for _ in range(100):
            random_perm = np.random.permutation(len(self.workers))
            random_time = sum(self.cost_matrix[i, random_perm[i]] 
                            for i in range(len(self.workers)))
            random_times.append(random_time)
        comparisons['random_average'] = float(np.mean(random_times))
        
        # Greedy assignment (assign best available each step)
        greedy_time = self._greedy_assignment()
        comparisons['greedy'] = greedy_time
        
        # Worst case (maximum cost assignment)
        row_indices, col_indices = linear_sum_assignment(-self.cost_matrix)
        worst_time = float(self.cost_matrix[row_indices, col_indices].sum())
        comparisons['worst_case'] = worst_time
        
        # Calculate improvements
        comparisons['improvement_vs_random'] = float(
            ((comparisons['random_average'] - comparisons['optimal']) / 
             comparisons['random_average']) * 100
        )
        comparisons['improvement_vs_greedy'] = float(
            ((comparisons['greedy'] - comparisons['optimal']) / 
             comparisons['greedy']) * 100
        )
        
        return comparisons
    
    def _greedy_assignment(self) -> float:
        """Calculate total time for greedy assignment strategy."""
        n = len(self.workers)
        available_workers = set(range(n))
        available_tasks = set(range(n))
        total_time = 0
        
        while available_tasks:
            # Find minimum cost among available assignments
            min_cost = float('inf')
            best_worker, best_task = None, None
            
            for i in available_workers:
                for j in available_tasks:
                    if self.cost_matrix[i, j] < min_cost:
                        min_cost = self.cost_matrix[i, j]
                        best_worker, best_task = i, j
            
            total_time += min_cost
            available_workers.remove(best_worker)
            available_tasks.remove(best_task)
        
        return float(total_time)


def load_problem_data(file_path: str = 'data/assignment_data.json') -> Dict[str, Any]:
    """Load problem data from JSON file."""
    try:
        with open(file_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return get_default_problem_data()


def get_default_problem_data() -> Dict[str, Any]:
    """Return default problem data for TechParts Inc."""
    return {
        "workers": [
            {"id": 0, "name": "Alice", "experience": "8 years"},
            {"id": 1, "name": "Bob", "experience": "4 years"},
            {"id": 2, "name": "Carol", "experience": "2 years"},
            {"id": 3, "name": "David", "experience": "10 years"},
            {"id": 4, "name": "Emma", "experience": "5 years"}
        ],
        "tasks": [
            {"id": 0, "name": "Microchip Inspection", "description": "Quality inspection of microchips"},
            {"id": 1, "name": "Circuit Board Assembly", "description": "Assembly of circuit boards"},
            {"id": 2, "name": "Sensor Calibration", "description": "Calibration of sensor components"},
            {"id": 3, "name": "Component Packaging", "description": "Packaging finished components"},
            {"id": 4, "name": "Final Testing", "description": "Final quality testing"}
        ],
        "cost_matrix": [
            [4, 6, 7, 5, 8],  # Alice
            [6, 5, 8, 7, 6],  # Bob
            [8, 7, 6, 9, 7],  # Carol
            [3, 4, 6, 4, 5],  # David
            [5, 6, 7, 6, 7]   # Emma
        ]
    }


def main():
    """Main function to run the Assignment Problem solver."""
    print("\n" + "=" * 80)
    print("ASSIGNMENT PROBLEM SOLVER - Q2")
    print("TechParts Inc. Task-Worker Allocation")
    print("=" * 80 + "\n")
    
    # Load problem data
    problem_data = load_problem_data()
    
    # Create solver instance
    solver = AssignmentProblemSolver(problem_data)
    
    # Solve the problem
    print("Solving Assignment Problem using Hungarian Algorithm...")
    print()
    solution = solver.solve()
    
    # Generate and print report
    report = solver.generate_report(solution)
    print(report)
    
    # Compare with alternatives
    print("\nCOMPARISON WITH ALTERNATIVE STRATEGIES:")
    print("-" * 80)
    comparisons = solver.compare_with_alternatives(solution)
    print(f"  Optimal (Hungarian)       : {comparisons['optimal']:6.1f} hours")
    print(f"  Greedy Strategy           : {comparisons['greedy']:6.1f} hours")
    print(f"  Random Assignment (avg)   : {comparisons['random_average']:6.1f} hours")
    print(f"  Worst Case                : {comparisons['worst_case']:6.1f} hours")
    print()
    print(f"  Improvement vs Greedy     : {comparisons['improvement_vs_greedy']:5.2f}%")
    print(f"  Improvement vs Random     : {comparisons['improvement_vs_random']:5.2f}%")
    print()
    
    # Save solution to JSON
    try:
        solution['comparisons'] = comparisons
        with open('data/assignment_solution.json', 'w') as f:
            json.dump(solution, f, indent=2)
        print("Solution saved to: data/assignment_solution.json")
    except:
        pass
    
    return solution


if __name__ == "__main__":
    main()
