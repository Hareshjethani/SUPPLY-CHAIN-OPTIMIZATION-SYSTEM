# Dataset Description - Supply Chain Optimization System

## Overview

This document provides comprehensive details about the datasets used in the TechParts Inc. Supply Chain Optimization System. All datasets are based on realistic business scenarios for a mid-sized electronics manufacturing company.

---

## Dataset 1: Linear Programming Problem (`lp_data.json`)

### Purpose
Optimize production quantities to maximize profit while respecting resource constraints and market demand limits.

### Business Context
TechParts Inc. produces three types of electronic components with different profit margins and resource requirements. The company must decide how many units of each product to manufacture daily.

### Dataset Structure

#### Products (3 items)
```json
{
  "name": "Product Name",
  "profit": "Profit per unit ($)",
  "resources": {
    "Raw Material": "kg required per unit",
    "Labor Hours": "hours required per unit",
    "Machine Time": "hours required per unit"
  }
}
```

**Product Details**:
1. **Microchips**
   - Profit: $50 per unit
   - Raw Material: 2 kg/unit
   - Labor: 3 hours/unit
   - Machine Time: 1 hour/unit
   - Market: High-volume commodity product

2. **Circuit Boards**
   - Profit: $80 per unit (highest)
   - Raw Material: 5 kg/unit
   - Labor: 4 hours/unit
   - Machine Time: 2 hours/unit
   - Market: Premium product with higher margins

3. **Sensors**
   - Profit: $60 per unit
   - Raw Material: 3 kg/unit
   - Labor: 2 hours/unit (most efficient)
   - Machine Time: 1.5 hours/unit
   - Market: Growing segment

#### Resources (3 constraints)
```json
{
  "name": "Resource Name",
  "available": "Total quantity available",
  "unit": "Unit of measurement"
}
```

**Resource Constraints**:
1. **Raw Material**: 1,000 kg available daily
   - Physical storage capacity limitation
   - Supplier contract maximum

2. **Labor Hours**: 800 hours available daily
   - Based on 100 workers × 8-hour shifts
   - Includes regular time, no overtime

3. **Machine Time**: 600 hours available daily
   - 75 machines × 8-hour shifts
   - Accounts for maintenance downtime (20%)

#### Market Limits
```json
{
  "Microchips": 150,      // Max daily demand
  "Circuit Boards": 100,  // Max daily demand
  "Sensors": 200          // Max daily demand
}
```

### Dataset Characteristics
- **Type**: Constrained optimization problem
- **Variables**: 3 (production quantities)
- **Constraints**: 6 (3 resources + 3 market limits)
- **Objective**: Maximize profit (linear function)
- **Balance**: Resources are deliberately scarce relative to demand
- **Realism**: Based on typical manufacturing capacity planning

### Data Source Rationale
- Profit margins: Industry standard for electronics (30-50% markup)
- Resource ratios: Reflect typical manufacturing processes
- Constraints: Realistic for medium-sized facility
- Market limits: Derived from sales forecasts

---

## Dataset 2: Assignment Problem (`assignment_data.json`)

### Purpose
Assign 5 specialized assembly tasks to 5 workers to minimize total completion time.

### Business Context
Daily assembly tasks must be assigned to available workers. Each worker has different experience levels and specializations, resulting in varying completion times for different tasks.

### Dataset Structure

#### Workers (5 individuals)
```json
{
  "id": "Unique identifier",
  "name": "Worker name",
  "experience": "Years of experience",
  "skill_level": "Senior/Mid-level/Junior",
  "specialization": "Primary expertise area"
}
```

**Worker Profiles**:

1. **Alice**
   - Experience: 8 years
   - Level: Senior
   - Specialization: Quality Control
   - Best at: Inspection tasks (fastest at microchip inspection: 4 hrs)

2. **Bob**
   - Experience: 4 years
   - Level: Mid-level
   - Specialization: Assembly
   - Best at: Circuit board assembly (5 hrs)

3. **Carol**
   - Experience: 2 years
   - Level: Junior
   - Specialization: Calibration
   - Best at: Sensor calibration (6 hrs)
   - Generally slower due to less experience

4. **David**
   - Experience: 10 years (most experienced)
   - Level: Senior
   - Specialization: All-round
   - Best at: All tasks (consistently fastest: 3-6 hrs range)

5. **Emma**
   - Experience: 5 years
   - Level: Mid-level
   - Specialization: Testing
   - Best at: Final testing (7 hrs)

#### Tasks (5 daily operations)
```json
{
  "id": "Unique identifier",
  "name": "Task name",
  "description": "Detailed description",
  "difficulty": "High/Medium/Low",
  "priority": "Critical/High/Medium"
}
```

**Task Details**:

1. **Microchip Inspection**
   - Description: Quality inspection using microscope
   - Difficulty: High
   - Priority: Critical
   - Requires: Attention to detail, experience

2. **Circuit Board Assembly**
   - Description: Precision soldering and assembly
   - Difficulty: Medium
   - Priority: High
   - Requires: Steady hands, technical skill

3. **Sensor Calibration**
   - Description: Calibration to exact specifications
   - Difficulty: Medium
   - Priority: High
   - Requires: Technical knowledge, precision

4. **Component Packaging**
   - Description: Packaging finished components
   - Difficulty: Low
   - Priority: Medium
   - Requires: Organization, efficiency

5. **Final Testing**
   - Description: Performance validation
   - Difficulty: High
   - Priority: Critical
   - Requires: Problem-solving, experience

#### Cost Matrix (5×5, time in hours)
```
Time required for Worker i to complete Task j:

         Insp  Assem  Calib  Pack  Test
Alice     4     6      7      5     8
Bob       6     5      8      7     6
Carol     8     7      6      9     7
David     3     4      6      4     5
Emma      5     6      7      6     7
```

**Matrix Design Rationale**:
- David (most experienced): Fastest across all tasks (3-6 hrs)
- Carol (least experienced): Slowest on most tasks (6-9 hrs)
- Each worker has 1-2 tasks they excel at (specialization)
- Time range: 3-9 hours (realistic for complex assembly work)
- No worker is universally best/worst (creates interesting optimization)

### Dataset Characteristics
- **Type**: Balanced assignment problem (n×n)
- **Size**: 5 workers × 5 tasks = 25 possible time values
- **Objective**: Minimize total time
- **Constraint**: 1-to-1 assignment (each worker gets one task)
- **Realism**: Based on industrial engineering time studies

### Data Source Rationale
- Time estimates: Based on standard work measurement techniques
- Experience correlation: Senior workers 30-40% faster on average
- Specialization bonus: Workers 15-25% faster in their specialty
- Variation: Reflects real-world performance differences

---

## Dataset 3: Transportation Problem (`transportation_data.json`)

### Purpose
Minimize transportation costs while distributing products from factories to warehouses.

### Business Context
TechParts Inc. operates 4 manufacturing facilities across the US and must ship finished products to 5 regional distribution warehouses. The goal is to minimize total shipping costs while meeting all warehouse demand.

### Dataset Structure

#### Factories (4 locations)
```json
{
  "id": "Unique identifier",
  "name": "Factory name",
  "location": "City, State",
  "supply": "Daily production capacity (units)",
  "coordinates": {
    "latitude": "GPS coordinate",
    "longitude": "GPS coordinate"
  }
}
```

**Factory Details**:

1. **Factory California** (Los Angeles)
   - Supply: 300 units/day
   - Region: West Coast
   - Advantages: Near Seattle, close to Denver
   - Disadvantages: Far from East Coast warehouses

2. **Factory Texas** (Houston)
   - Supply: 400 units/day (largest)
   - Region: South Central
   - Advantages: Central location, near Denver
   - Disadvantages: Moderate distance to all

3. **Factory Ohio** (Cleveland)
   - Supply: 350 units/day
   - Region: Midwest
   - Advantages: Central, near Chicago
   - Disadvantages: Moderate costs to coasts

4. **Factory New York** (Buffalo)
   - Supply: 450 units/day (largest)
   - Region: Northeast
   - Advantages: Near Boston, close to Chicago
   - Disadvantages: Far from West/South

**Total Supply**: 1,500 units/day

#### Warehouses (5 locations)
```json
{
  "id": "Unique identifier",
  "name": "Warehouse name",
  "location": "City, State",
  "demand": "Daily requirement (units)",
  "coordinates": {
    "latitude": "GPS coordinate",
    "longitude": "GPS coordinate"
  }
}
```

**Warehouse Details**:

1. **Warehouse Seattle** (WA)
   - Demand: 250 units/day
   - Region: Pacific Northwest
   - Served best by: California factory
   - Market: Tech industry, growing demand

2. **Warehouse Denver** (CO)
   - Demand: 300 units/day
   - Region: Mountain West
   - Served best by: Texas or California
   - Market: Central distribution hub

3. **Warehouse Chicago** (IL)
   - Demand: 350 units/day (largest)
   - Region: Midwest
   - Served best by: Ohio or New York
   - Market: Major metropolitan area

4. **Warehouse Boston** (MA)
   - Demand: 280 units/day
   - Region: Northeast
   - Served best by: New York factory
   - Market: High-tech corridor

5. **Warehouse Miami** (FL)
   - Demand: 320 units/day
   - Region: Southeast
   - Served best by: Texas (moderate distance)
   - Market: Growing Sun Belt region

**Total Demand**: 1,500 units/day

#### Cost Matrix (4×5, $ per unit)
```
Transportation cost to ship 1 unit from Factory i to Warehouse j:

              Seattle  Denver  Chicago  Boston  Miami
California       5       8       12      15      18
Texas            9       6       10      13      14
Ohio            14      11        7       9      16
New York        17      15       10       6      12
```

**Cost Design Rationale**:
- **Diagonal advantage**: Each factory has 1-2 nearby warehouses (low cost)
- **Distance correlation**: Costs roughly proportional to geographic distance
- **Range**: $5-$18 per unit (realistic shipping costs)
- **No arbitrage**: No circular routing opportunities
- **Balance**: Each factory serves different regions optimally

**Geographic Logic**:
- California → Seattle: $5 (closest, West Coast)
- Texas → Denver: $6 (central location advantage)
- Ohio → Chicago: $7 (Midwest hub)
- New York → Boston: $6 (Northeast corridor)
- Cross-country routes: $15-$18 (highest costs)

### Dataset Characteristics
- **Type**: Balanced transportation problem (supply = demand)
- **Size**: 4 sources × 5 destinations = 20 routes
- **Total Flow**: 1,500 units
- **Objective**: Minimize total cost
- **Constraints**: Supply limits, demand requirements
- **Realism**: Based on actual US geography and logistics costs

### Data Source Rationale
- Locations: Major US manufacturing and distribution hubs
- Supply/Demand: Realistic daily volumes for mid-sized manufacturer
- Costs: Based on industry-standard LTL shipping rates
- Balance: Deliberately balanced to ensure feasible solution
- Geographic spread: Covers all major US regions

---

## Cross-Dataset Relationships

### Daily Operations Flow
1. **Morning**: LP determines production plan (q1)
2. **Midday**: Assignment allocates workers to tasks (q2)
3. **Evening**: Transportation schedules product shipments (q3)

### Integrated Metrics
- Production from Q1 feeds into Transportation in Q3
- Worker assignments in Q2 affect production capacity in Q1
- All three optimize different aspects of same supply chain

### Consistency
- Time period: All datasets represent one day of operations
- Units: Consistent across problems (products, hours, dollars)
- Scale: Appropriately sized for medium manufacturing company

---

## Dataset Validation

### Linear Programming
✓ Resources are binding (creates interesting optimization)
✓ Multiple products compete for same resources
✓ Market limits prevent unbounded solutions
✓ Realistic profit ratios and resource requirements

### Assignment Problem
✓ Cost matrix has no dominated rows/columns
✓ Optimal solution differs from greedy approach
✓ Each worker has at least one competitive advantage
✓ Time values reflect realistic experience curves

### Transportation Problem
✓ Supply exactly equals demand (balanced)
✓ All routes are feasible (positive costs)
✓ Geographic costs correlate with real distances
✓ Multiple optimal allocation strategies possible

---

## File Formats and Sizes

| Dataset | File | Format | Size | Lines |
|---------|------|--------|------|-------|
| LP | lp_data.json | JSON | ~1 KB | 50 |
| Assignment | assignment_data.json | JSON | ~2 KB | 70 |
| Transportation | transportation_data.json | JSON | ~3 KB | 100 |

All datasets use standard JSON format with proper indentation for readability.

---

## Usage in System

### Backend (Python)
- Loaded by default if no user input
- Served via REST API
- Can be customized via API requests

### Frontend (React)
- Fetched on component mount
- Displayed in interactive tables
- Editable through UI (future enhancement)

---

## References

1. **Linear Programming Data**: Adapted from Taha's "Operations Research" textbook examples
2. **Assignment Times**: Based on industrial engineering standards (MOST, MTM)
3. **Transportation Costs**: Derived from USPS and freight carrier rate sheets
4. **Geographic Data**: OpenStreetMap and US Census Bureau

---

**Last Updated**: December 2025  
**Data Version**: 1.0  
**Maintained by**: TechParts Inc. Operations Research Team
