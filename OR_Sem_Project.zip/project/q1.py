"""
Question 1: Linear Programming - Production Optimization
=========================================================

Problem: Maximize profit for TechParts Inc. by determining optimal production
quantities for three products (Microchips, Circuit Boards, Sensors) subject to
resource constraints (raw materials, labor hours, machine time, market demand).

Method: Simplex Algorithm using scipy.optimize.linprog
Reference: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.linprog.html

Author: TechParts Inc. Operations Research Team
Date: December 2025
"""

import numpy as np
from scipy.optimize import linprog
import json
from typing import Dict, List, Tuple, Any


class LinearProgrammingOptimizer:
    """
    Solves Linear Programming problems using the Simplex method.
    
    This class handles maximization problems by converting them to minimization
    problems (multiplying objective function by -1).
    """
    
    def __init__(self, problem_data: Dict[str, Any]):
        """
        Initialize the LP optimizer with problem data.
        
        Args:
            problem_data: Dictionary containing:
                - products: List of products with profit and resource requirements
                - resources: List of resource constraints
                - market_limits: Maximum demand for each product
        """
        self.problem_data = problem_data
        self.products = problem_data['products']
        self.resources = problem_data['resources']
        self.market_limits = problem_data['market_limits']
        
    def prepare_optimization_problem(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray, List[Tuple]]:
        """
        Prepare the LP problem in standard form for scipy.linprog.
        
        Standard form:
            Minimize: c^T * x
            Subject to: A_ub @ x <= b_ub
                       A_eq @ x == b_eq
                       bounds for x
        
        Returns:
            c: Coefficients for objective function (negated for maximization)
            A_ub: Coefficient matrix for inequality constraints
            b_ub: Right-hand side of inequality constraints
            bounds: Bounds for each variable
        """
        n_products = len(self.products)
        
        # Objective function coefficients (negate for maximization)
        # Original: Maximize 50x1 + 80x2 + 60x3
        # Converted: Minimize -50x1 - 80x2 - 60x3
        c = np.array([-product['profit'] for product in self.products])
        
        # Inequality constraints: A_ub @ x <= b_ub
        # Each resource constraint + market limit constraints
        n_constraints = len(self.resources) + n_products
        A_ub = []
        b_ub = []
        
        # Resource constraints (raw material, labor, machine time)
        for resource in self.resources:
            constraint_row = [product['resources'][resource['name']] 
                            for product in self.products]
            A_ub.append(constraint_row)
            b_ub.append(resource['available'])
        
        # Market demand constraints (maximum production limits)
        for i, product in enumerate(self.products):
            constraint_row = [0] * n_products
            constraint_row[i] = 1  # Only constrain this product
            A_ub.append(constraint_row)
            b_ub.append(self.market_limits[product['name']])
        
        A_ub = np.array(A_ub)
        b_ub = np.array(b_ub)
        
        # Bounds for variables (all non-negative)
        bounds = [(0, None) for _ in range(n_products)]
        
        return c, A_ub, b_ub, bounds
    
    def solve(self) -> Dict[str, Any]:
        """
        Solve the linear programming problem using the Simplex method.
        
        Returns:
            Dictionary containing:
                - success: Whether optimization succeeded
                - optimal_production: Production quantities for each product
                - max_profit: Maximum achievable profit
                - resource_utilization: How much of each resource is used
                - slack: Unused resources
                - message: Status message
                - simplex_steps: Step-by-step simplex tableau iterations
        """
        c, A_ub, b_ub, bounds = self.prepare_optimization_problem()
        
        # Generate simplex tableau steps (simplified visualization)
        simplex_steps = self._generate_simplex_steps(c, A_ub, b_ub)
        
        # Solve using the revised simplex method
        # method='highs' uses the HiGHS solver (recommended for LP)
        result = linprog(
            c=c,
            A_ub=A_ub,
            b_ub=b_ub,
            bounds=bounds,
            method='highs',  # HiGHS is more robust than simplex
            options={'disp': False}
        )
        
        if not result.success:
            return {
                'success': False,
                'message': f"Optimization failed: {result.message}",
                'optimal_production': None,
                'max_profit': None
            }
        
        # Extract results
        optimal_production = {
            product['name']: round(result.x[i], 2)
            for i, product in enumerate(self.products)
        }
        
        max_profit = round(-result.fun, 2)  # Negate back for maximization
        
        # Calculate resource utilization
        resource_usage = np.dot(A_ub[:len(self.resources)], result.x)
        resource_utilization = {}
        slack = {}
        
        for i, resource in enumerate(self.resources):
            used = round(resource_usage[i], 2)
            available = resource['available']
            resource_utilization[resource['name']] = {
                'used': used,
                'available': available,
                'percentage': round((used / available) * 100, 2)
            }
            slack[resource['name']] = round(available - used, 2)
        
        # Calculate market utilization (demand fill rate)
        market_utilization = {}
        for i, product in enumerate(self.products):
            produced = result.x[i]
            max_demand = self.market_limits[product['name']]
            market_utilization[product['name']] = {
                'produced': round(produced, 2),
                'max_demand': max_demand,
                'percentage': round((produced / max_demand) * 100, 2)
            }
        
        return {
            'success': True,
            'optimal_production': optimal_production,
            'max_profit': max_profit,
            'resource_utilization': resource_utilization,
            'market_utilization': market_utilization,
            'slack': slack,
            'message': 'Optimization successful',
            'iterations': result.get('nit', 'N/A'),
            'simplex_steps': simplex_steps
        }
    
    def _generate_simplex_steps(self, c: np.ndarray, A_ub: np.ndarray, b_ub: np.ndarray) -> List[Dict[str, Any]]:
        """
        Generate simplified simplex tableau steps for visualization.
        
        Since we're using HiGHS solver (not pure simplex), we'll create
        educational step-by-step tableaus showing the simplex method conceptually.
        
        Args:
            c: Objective function coefficients
            A_ub: Constraint coefficient matrix
            b_ub: Right-hand side values
            
        Returns:
            List of simplex tableau steps
        """
        steps = []
        n_vars = len(c)
        n_constraints = len(b_ub)
        
        # Step 0: Initial setup - convert to standard form
        steps.append({
            'iteration': 0,
            'description': 'Initial Setup: Convert to standard form by adding slack variables',
            'basis': ['s' + str(i+1) for i in range(n_constraints)],
            'basic_vars': list(b_ub),
            'objective_value': 0.0,
            'note': 'Starting with all slack variables in the basis'
        })
        
        # Step 1: Initial tableau
        # Create augmented matrix [A | I | b] with objective row
        initial_tableau = np.zeros((n_constraints + 1, n_vars + n_constraints + 1))
        initial_tableau[0, :n_vars] = c  # Objective coefficients (negated)
        initial_tableau[1:, :n_vars] = A_ub  # Constraint coefficients
        initial_tableau[1:, n_vars:n_vars+n_constraints] = np.eye(n_constraints)  # Slack variables
        initial_tableau[1:, -1] = b_ub  # RHS
        
        steps.append({
            'iteration': 1,
            'description': 'Initial Simplex Tableau',
            'tableau': initial_tableau.tolist(),
            'column_headers': [f'x{i+1}' for i in range(n_vars)] + 
                            [f's{i+1}' for i in range(n_constraints)] + ['RHS'],
            'row_headers': ['Z'] + [f's{i+1}' for i in range(n_constraints)],
            'basis': ['s' + str(i+1) for i in range(n_constraints)],
            'objective_value': 0.0,
            'note': 'All decision variables are zero, only slack variables are in basis'
        })
        
        # Simulate a few iterations (educational purposes)
        # In reality, HiGHS uses more sophisticated methods
        
        # Step 2: After first pivot (example)
        steps.append({
            'iteration': 2,
            'description': 'After First Iteration: Entering variable with most negative coefficient in Z row',
            'note': 'Pivot to bring a decision variable into the basis',
            'entering_var': 'x with most profit',
            'leaving_var': 'Slack variable with minimum ratio',
            'improvement': 'Objective function value increases'
        })
        
        # Step 3: Intermediate iteration
        steps.append({
            'iteration': 3,
            'description': 'Intermediate Iteration: Continue improving the solution',
            'note': 'Each iteration moves to an adjacent corner point with better objective value'
        })
        
        # Final step will be added after we get the actual solution
        return steps
    
    def generate_report(self, solution: Dict[str, Any]) -> str:
        """
        Generate a detailed text report of the optimization results.
        
        Args:
            solution: Solution dictionary from solve()
            
        Returns:
            Formatted report string
        """
        if not solution['success']:
            return f"OPTIMIZATION FAILED\n{solution['message']}"
        
        report = []
        report.append("=" * 70)
        report.append("LINEAR PROGRAMMING OPTIMIZATION REPORT")
        report.append("TechParts Inc. - Production Optimization")
        report.append("=" * 70)
        report.append("")
        
        report.append("OPTIMAL PRODUCTION PLAN:")
        report.append("-" * 70)
        for product_name, quantity in solution['optimal_production'].items():
            product_data = next(p for p in self.products if p['name'] == product_name)
            profit_contribution = quantity * product_data['profit']
            report.append(f"  {product_name:20s}: {quantity:8.2f} units  "
                         f"(Profit: ${profit_contribution:,.2f})")
        report.append("")
        
        report.append(f"MAXIMUM PROFIT: ${solution['max_profit']:,.2f}")
        report.append("")
        
        report.append("RESOURCE UTILIZATION:")
        report.append("-" * 70)
        for resource_name, util in solution['resource_utilization'].items():
            report.append(f"  {resource_name:20s}: {util['used']:8.2f} / "
                         f"{util['available']:8.2f} ({util['percentage']:5.2f}% used)")
        report.append("")
        
        report.append("UNUSED RESOURCES (SLACK):")
        report.append("-" * 70)
        for resource_name, slack_value in solution['slack'].items():
            report.append(f"  {resource_name:20s}: {slack_value:8.2f} units")
        report.append("")
        
        report.append("MARKET DEMAND UTILIZATION:")
        report.append("-" * 70)
        for product_name, util in solution['market_utilization'].items():
            report.append(f"  {product_name:20s}: {util['produced']:8.2f} / "
                         f"{util['max_demand']:8.2f} ({util['percentage']:5.2f}% of max)")
        report.append("")
        
        report.append("=" * 70)
        
        return "\n".join(report)


def load_problem_data(file_path: str = 'data/lp_data.json') -> Dict[str, Any]:
    """Load problem data from JSON file."""
    try:
        with open(file_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        # Return default problem data if file doesn't exist
        return get_default_problem_data()


def get_default_problem_data() -> Dict[str, Any]:
    """
    Return default problem data for TechParts Inc.
    
    Returns:
        Dictionary with products, resources, and market limits
    """
    return {
        "products": [
            {
                "name": "Microchips",
                "profit": 50,
                "resources": {
                    "Raw Material": 2,
                    "Labor Hours": 3,
                    "Machine Time": 1
                }
            },
            {
                "name": "Circuit Boards",
                "profit": 80,
                "resources": {
                    "Raw Material": 5,
                    "Labor Hours": 4,
                    "Machine Time": 2
                }
            },
            {
                "name": "Sensors",
                "profit": 60,
                "resources": {
                    "Raw Material": 3,
                    "Labor Hours": 2,
                    "Machine Time": 1.5
                }
            }
        ],
        "resources": [
            {"name": "Raw Material", "available": 1000},
            {"name": "Labor Hours", "available": 800},
            {"name": "Machine Time", "available": 600}
        ],
        "market_limits": {
            "Microchips": 150,
            "Circuit Boards": 100,
            "Sensors": 200
        }
    }


def main():
    """Main function to run the Linear Programming optimization."""
    print("\n" + "=" * 70)
    print("LINEAR PROGRAMMING OPTIMIZER - Q1")
    print("TechParts Inc. Production Optimization")
    print("=" * 70 + "\n")
    
    # Load problem data
    problem_data = load_problem_data()
    
    # Create optimizer instance
    optimizer = LinearProgrammingOptimizer(problem_data)
    
    # Solve the problem
    print("Solving Linear Programming problem using Simplex method...")
    print()
    solution = optimizer.solve()
    
    # Generate and print report
    report = optimizer.generate_report(solution)
    print(report)
    
    # Save solution to JSON for API use
    try:
        with open('data/lp_solution.json', 'w') as f:
            json.dump(solution, f, indent=2)
        print("\nSolution saved to: data/lp_solution.json")
    except:
        pass
    
    return solution


if __name__ == "__main__":
    main()
