"""
Flask API Server for Supply Chain Optimization System
=====================================================

This server exposes REST endpoints for:
1. Linear Programming (Production Optimization)
2. Assignment Problem (Task-Worker Allocation)
3. Transportation Problem (Product Distribution)

Dependencies:
    - Flask: Web framework
    - Flask-CORS: Cross-origin resource sharing
    - scipy: Optimization algorithms
    - numpy: Numerical computations

Author: TechParts Inc.
Date: December 2025
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from flask.json.provider import DefaultJSONProvider
import json
import os
import sys
import numpy as np

# Import our optimization modules
from q1 import LinearProgrammingOptimizer, get_default_problem_data as get_lp_data
from q2 import AssignmentProblemSolver, get_default_problem_data as get_assignment_data
from q3 import TransportationProblemSolver, get_default_problem_data as get_transportation_data


# Custom JSON encoder to handle NumPy types
class NumpyJSONProvider(DefaultJSONProvider):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        return super().default(obj)


# Initialize Flask app
app = Flask(__name__)
app.json = NumpyJSONProvider(app)
CORS(app)  # Enable CORS for all routes

# Configure app
app.config['JSON_SORT_KEYS'] = False


# ============================================================================
# Helper Functions
# ============================================================================

def load_data_file(filename):
    """Load data from JSON file, return default if not found."""
    filepath = os.path.join('data', filename)
    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def save_solution(filename, data):
    """Save solution to JSON file."""
    filepath = os.path.join('data', filename)
    try:
        # Convert numpy types to native Python types
        def convert_numpy(obj):
            if isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, dict):
                return {key: convert_numpy(value) for key, value in obj.items()}
            elif isinstance(obj, list):
                return [convert_numpy(item) for item in obj]
            return obj
        
        converted_data = convert_numpy(data)
        with open(filepath, 'w') as f:
            json.dump(converted_data, f, indent=2)
        return True
    except Exception as e:
        print(f"Error saving solution: {e}")
        return False


# ============================================================================
# API Routes - Health Check
# ============================================================================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'message': 'Supply Chain Optimization API is running',
        'version': '1.0.0'
    })


# ============================================================================
# API Routes - Linear Programming (Q1)
# ============================================================================

@app.route('/api/lp/data', methods=['GET'])
def get_lp_problem_data():
    """Get Linear Programming problem data."""
    data = load_data_file('lp_data.json') or get_lp_data()
    return jsonify(data)


@app.route('/api/lp/solve', methods=['POST'])
def solve_lp():
    """
    Solve Linear Programming problem.
    
    Request body (optional):
        Custom problem data in same format as lp_data.json
    
    Returns:
        Optimal solution with production quantities and profit
    """
    try:
        # Get problem data from request or use default
        if request.json:
            problem_data = request.json
        else:
            problem_data = load_data_file('lp_data.json') or get_lp_data()
        
        # Create optimizer and solve
        optimizer = LinearProgrammingOptimizer(problem_data)
        solution = optimizer.solve()
        
        # Save solution
        if solution['success']:
            save_solution('lp_solution.json', solution)
        
        return jsonify(solution)
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error solving LP problem: {str(e)}',
            'error': str(e)
        }), 500


@app.route('/api/lp/report', methods=['POST'])
def get_lp_report():
    """Get formatted text report for LP solution."""
    try:
        if request.json:
            problem_data = request.json
        else:
            problem_data = load_data_file('lp_data.json') or get_lp_data()
        
        optimizer = LinearProgrammingOptimizer(problem_data)
        solution = optimizer.solve()
        report = optimizer.generate_report(solution)
        
        return jsonify({
            'success': True,
            'report': report,
            'solution': solution
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error generating LP report: {str(e)}'
        }), 500


# ============================================================================
# API Routes - Assignment Problem (Q2)
# ============================================================================

@app.route('/api/assignment/data', methods=['GET'])
def get_assignment_problem_data():
    """Get Assignment Problem data."""
    data = load_data_file('assignment_data.json') or get_assignment_data()
    return jsonify(data)


@app.route('/api/assignment/solve', methods=['POST'])
def solve_assignment():
    """
    Solve Assignment Problem using Hungarian Algorithm.
    
    Request body (optional):
        Custom problem data with workers, tasks, and cost_matrix
    
    Returns:
        Optimal task-worker assignments and total time
    """
    try:
        # Get problem data
        if request.json:
            problem_data = request.json
        else:
            problem_data = load_data_file('assignment_data.json') or get_assignment_data()
        
        # Create solver and solve
        solver = AssignmentProblemSolver(problem_data)
        solution = solver.solve()
        
        # Add comparisons
        if solution['success']:
            comparisons = solver.compare_with_alternatives(solution)
            solution['comparisons'] = comparisons
            save_solution('assignment_solution.json', solution)
        
        return jsonify(solution)
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error solving Assignment problem: {str(e)}',
            'error': str(e)
        }), 500


@app.route('/api/assignment/report', methods=['POST'])
def get_assignment_report():
    """Get formatted text report for Assignment solution."""
    try:
        if request.json:
            problem_data = request.json
        else:
            problem_data = load_data_file('assignment_data.json') or get_assignment_data()
        
        solver = AssignmentProblemSolver(problem_data)
        solution = solver.solve()
        report = solver.generate_report(solution)
        comparisons = solver.compare_with_alternatives(solution)
        
        return jsonify({
            'success': True,
            'report': report,
            'solution': solution,
            'comparisons': comparisons
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error generating Assignment report: {str(e)}'
        }), 500


# ============================================================================
# API Routes - Transportation Problem (Q3)
# ============================================================================

@app.route('/api/transportation/data', methods=['GET'])
def get_transportation_problem_data():
    """Get Transportation Problem data."""
    data = load_data_file('transportation_data.json') or get_transportation_data()
    return jsonify(data)


@app.route('/api/transportation/solve', methods=['POST'])
def solve_transportation():
    """
    Solve Transportation Problem.
    
    Request body (optional):
        Custom problem data with factories, warehouses, and cost_matrix
    
    Returns:
        Optimal shipment plan and minimum transportation cost
    """
    try:
        # Get problem data
        if request.json:
            problem_data = request.json
        else:
            problem_data = load_data_file('transportation_data.json') or get_transportation_data()
        
        # Create solver and solve
        solver = TransportationProblemSolver(problem_data)
        solution = solver.solve()
        
        # Save solution
        if solution['success']:
            save_solution('transportation_solution.json', solution)
        
        return jsonify(solution)
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error solving Transportation problem: {str(e)}',
            'error': str(e)
        }), 500


@app.route('/api/transportation/report', methods=['POST'])
def get_transportation_report():
    """Get formatted text report for Transportation solution."""
    try:
        if request.json:
            problem_data = request.json
        else:
            problem_data = load_data_file('transportation_data.json') or get_transportation_data()
        
        solver = TransportationProblemSolver(problem_data)
        solution = solver.solve()
        report = solver.generate_report(solution)
        
        return jsonify({
            'success': True,
            'report': report,
            'solution': solution
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error generating Transportation report: {str(e)}'
        }), 500


# ============================================================================
# API Routes - Combined Solutions
# ============================================================================

@app.route('/api/solve-all', methods=['POST'])
def solve_all():
    """
    Solve all three optimization problems at once.
    
    Returns:
        Solutions for LP, Assignment, and Transportation problems
    """
    try:
        results = {
            'success': True,
            'message': 'All problems solved successfully'
        }
        
        # Solve Linear Programming
        lp_data = load_data_file('lp_data.json') or get_lp_data()
        lp_optimizer = LinearProgrammingOptimizer(lp_data)
        results['linear_programming'] = lp_optimizer.solve()
        
        # Solve Assignment Problem
        assignment_data = load_data_file('assignment_data.json') or get_assignment_data()
        assignment_solver = AssignmentProblemSolver(assignment_data)
        results['assignment'] = assignment_solver.solve()
        
        # Solve Transportation Problem
        transportation_data = load_data_file('transportation_data.json') or get_transportation_data()
        transportation_solver = TransportationProblemSolver(transportation_data)
        results['transportation'] = transportation_solver.solve()
        
        return jsonify(results)
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error solving problems: {str(e)}',
            'error': str(e)
        }), 500


# ============================================================================
# Error Handlers
# ============================================================================

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return jsonify({
        'success': False,
        'message': 'Endpoint not found',
        'error': '404 Not Found'
    }), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    return jsonify({
        'success': False,
        'message': 'Internal server error',
        'error': str(error)
    }), 500


# ============================================================================
# Main
# ============================================================================

if __name__ == '__main__':
    print("\n" + "="*70)
    print("Supply Chain Optimization API Server")
    print("TechParts Inc. - Operations Research System")
    print("="*70)
    print("\nAPI Endpoints:")
    print("  GET  /api/health                     - Health check")
    print("\n  Linear Programming (Q1):")
    print("  GET  /api/lp/data                    - Get problem data")
    print("  POST /api/lp/solve                   - Solve LP problem")
    print("  POST /api/lp/report                  - Get formatted report")
    print("\n  Assignment Problem (Q2):")
    print("  GET  /api/assignment/data            - Get problem data")
    print("  POST /api/assignment/solve           - Solve assignment")
    print("  POST /api/assignment/report          - Get formatted report")
    print("\n  Transportation Problem (Q3):")
    print("  GET  /api/transportation/data        - Get problem data")
    print("  POST /api/transportation/solve       - Solve transportation")
    print("  POST /api/transportation/report      - Get formatted report")
    print("\n  Combined:")
    print("  POST /api/solve-all                  - Solve all problems")
    print("\n" + "="*70)
    print("\nStarting server on http://localhost:5000")
    print("Press Ctrl+C to stop\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
