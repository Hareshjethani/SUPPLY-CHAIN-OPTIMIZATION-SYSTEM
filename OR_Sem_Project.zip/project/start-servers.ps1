#!/usr/bin/env pwsh
# Start both backend and frontend servers

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "TechParts Inc. - Supply Chain Optimizer" -ForegroundColor Cyan
Write-Host "Starting Development Servers" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Function to check if port is available
function Test-Port {
    param($Port)
    $connection = Test-NetConnection -ComputerName localhost -Port $Port -WarningAction SilentlyContinue
    return -not $connection.TcpTestSucceeded
}

# Check if backend port is available
if (-not (Test-Port 5000)) {
    Write-Host "✗ Port 5000 is already in use!" -ForegroundColor Red
    Write-Host "  Please stop the application using port 5000 or change the port in api_server.py" -ForegroundColor Yellow
    exit 1
}

Write-Host "Starting Backend API Server on port 5000..." -ForegroundColor Yellow
Write-Host ""

# Start backend in new window
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PSScriptRoot'; python api_server.py"

Write-Host "✓ Backend server starting in new window..." -ForegroundColor Green
Write-Host ""

# Wait a moment for backend to start
Start-Sleep -Seconds 2

Write-Host "Starting Frontend Development Server on port 3000..." -ForegroundColor Yellow
Write-Host ""

# Start frontend in new window
$frontendPath = Join-Path $PSScriptRoot "frontend"
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$frontendPath'; npm run dev"

Write-Host "✓ Frontend server starting in new window..." -ForegroundColor Green
Write-Host ""

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Servers Started!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Backend API:  http://localhost:5000" -ForegroundColor White
Write-Host "Frontend UI:  http://localhost:3000" -ForegroundColor White
Write-Host ""
Write-Host "Two PowerShell windows have been opened." -ForegroundColor Yellow
Write-Host "Close those windows to stop the servers." -ForegroundColor Yellow
Write-Host ""
Write-Host "Press any key to exit this window..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
