# Quick Start Guide

## 🚀 Running the Project in 5 Minutes

### Step 1: Install Python Dependencies (1 minute)

```powershell
# Make sure you're in the project directory
cd "c:\G\assignment work\capstone\oklan\project"

# Install required packages
pip install flask flask-cors scipy numpy
```

### Step 2: Test Python Scripts (2 minutes)

```powershell
# Test each optimization problem
python q1.py
python q2.py
python q3.py
```

You should see detailed results printed to the console for each problem.

### Step 3: Start Backend API (30 seconds)

```powershell
# Start the Flask server
python api_server.py
```

Keep this terminal open. The API will run on `http://localhost:5000`

### Step 4: Install Frontend Dependencies (1 minute)

Open a **NEW** PowerShell terminal:

```powershell
# Navigate to frontend directory
cd "c:\G\assignment work\capstone\oklan\project\frontend"

# Install npm packages
npm install
```

### Step 5: Start Frontend (30 seconds)

```powershell
# Still in frontend directory
npm run dev
```

The frontend will start on `http://localhost:3000`

### Step 6: Open in Browser

Open your browser and navigate to:
```
http://localhost:3000
```

---

## 🎯 What You Should See

### Dashboard
- Overview of all three optimization problems
- Quick solve button for all problems
- Visual cards for each problem type

### Linear Programming Tab
- Problem data (products, resources, constraints)
- Solve button
- Results showing optimal production quantities
- Maximum profit achieved
- Resource utilization charts

### Assignment Problem Tab
- Workers and tasks list
- Cost matrix (time matrix)
- Solve button
- Optimal assignments
- Comparison with other methods

### Transportation Problem Tab
- Factories and warehouses
- Cost matrix
- Solve button
- Optimal shipment plan
- Total transportation cost

---

## 🐛 Troubleshooting

### Python Issues

**"No module named 'flask'"**
```powershell
pip install flask flask-cors scipy numpy
```

**"Port 5000 already in use"**
- Stop other programs using port 5000
- Or edit `api_server.py` line 267 to use different port

### Frontend Issues

**"npm: command not found"**
- Install Node.js from https://nodejs.org/

**"Port 3000 already in use"**
- The terminal will suggest a different port (like 3001)
- Type 'y' to use the suggested port

### API Connection Issues

**"Network Error" in frontend**
- Make sure backend is running (`python api_server.py`)
- Check that it's on port 5000
- Verify `http://localhost:5000/api/health` works in browser

---

## 📝 Quick Test Commands

### Test Backend API

```powershell
# Test health endpoint
curl http://localhost:5000/api/health

# Test LP solve
curl -X POST http://localhost:5000/api/lp/solve

# Test Assignment solve
curl -X POST http://localhost:5000/api/assignment/solve

# Test Transportation solve
curl -X POST http://localhost:5000/api/transportation/solve
```

### Expected API Response

```json
{
  "success": true,
  "message": "...",
  "optimal_production": { ... },
  "max_profit": 15640.0
}
```

---

## 🎨 Customizing the Data

### Edit Problem Data

All problem data is in the `data/` folder:

- `data/lp_data.json` - Linear Programming
- `data/assignment_data.json` - Assignment Problem
- `data/transportation_data.json` - Transportation Problem

After editing, restart the backend server to load new data.

---

## 💡 Tips

1. **Keep both terminals open** - one for backend, one for frontend
2. **Refresh browser** if solutions don't load
3. **Check browser console** (F12) for errors
4. **Solutions are saved** in `data/` folder as `*_solution.json`

---

## 📞 Getting Help

If you encounter issues:

1. Check that Python 3.8+ is installed: `python --version`
2. Check that Node.js 16+ is installed: `node --version`
3. Verify all dependencies installed correctly
4. Check both terminals for error messages
5. Try restarting both servers

---

## ✅ Success Checklist

- [ ] Python dependencies installed
- [ ] All three Python scripts run successfully
- [ ] Backend API starts without errors
- [ ] Frontend dependencies installed
- [ ] Frontend starts and opens in browser
- [ ] Dashboard loads and displays cards
- [ ] Can solve Linear Programming problem
- [ ] Can solve Assignment problem
- [ ] Can solve Transportation problem
- [ ] Solutions display with charts and visualizations

**If all items are checked, you're good to go! 🎉**
