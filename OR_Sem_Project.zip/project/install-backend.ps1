# Install Python dependencies
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "TechParts Inc. - Supply Chain Optimizer" -ForegroundColor Cyan
Write-Host "Backend Installation Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check Python version
Write-Host "Checking Python version..." -ForegroundColor Yellow
$pythonVersion = python --version 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Python found: $pythonVersion" -ForegroundColor Green
} else {
    Write-Host "✗ Python not found. Please install Python 3.8 or higher." -ForegroundColor Red
    exit 1
}

Write-Host ""

# Install dependencies
Write-Host "Installing Python dependencies..." -ForegroundColor Yellow
pip install -r requirements.txt

if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Dependencies installed successfully!" -ForegroundColor Green
} else {
    Write-Host "✗ Failed to install dependencies" -ForegroundColor Red
    exit 1
}

Write-Host ""

# Test imports
Write-Host "Testing imports..." -ForegroundColor Yellow
python -c "import flask, scipy, numpy; print('✓ All modules imported successfully')"

if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Import test passed!" -ForegroundColor Green
} else {
    Write-Host "✗ Import test failed" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Installation Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Test individual scripts: python q1.py" -ForegroundColor White
Write-Host "2. Start API server: python api_server.py" -ForegroundColor White
Write-Host "3. Install frontend: cd frontend; npm install" -ForegroundColor White
Write-Host ""
