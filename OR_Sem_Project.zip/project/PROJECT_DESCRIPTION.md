# Supply Chain Optimization System - TechParts Inc.

## Real-World Problem Statement

**Company**: TechParts Inc. - A mid-sized electronics component manufacturer

### Business Context
TechParts Inc. manufactures electronic components (microchips, circuit boards, sensors) across 4 production facilities and distributes them to 5 regional warehouses. The company faces daily operational challenges:

1. **Resource Allocation Challenge**: Limited production capacity, raw materials, and labor hours must be optimally allocated across different product lines to maximize profit.

2. **Task Assignment Challenge**: Specialized assembly tasks must be assigned to skilled workers based on their efficiency and expertise to minimize total completion time.

3. **Distribution Challenge**: Finished products must be transported from factories to warehouses cost-effectively while meeting demand.

---

## Problem 1: Linear Programming - Production Optimization

### Objective
Maximize total profit by determining optimal production quantities for each product type given resource constraints.

### Products Manufactured
- **Product A**: Microchips (Profit: $50 per unit)
- **Product B**: Circuit Boards (Profit: $80 per unit)
- **Product C**: Sensors (Profit: $60 per unit)

### Constraints
1. **Raw Material**: 1000 kg available
   - Product A: 2 kg/unit
   - Product B: 5 kg/unit
   - Product C: 3 kg/unit

2. **Labor Hours**: 800 hours available
   - Product A: 3 hours/unit
   - Product B: 4 hours/unit
   - Product C: 2 hours/unit

3. **Machine Time**: 600 hours available
   - Product A: 1 hour/unit
   - Product B: 2 hours/unit
   - Product C: 1.5 hours/unit

4. **Market Demand Constraints**:
   - Product A: Maximum 150 units
   - Product B: Maximum 100 units
   - Product C: Maximum 200 units

### Decision Variables
- x₁ = Number of units of Product A to produce
- x₂ = Number of units of Product B to produce
- x₃ = Number of units of Product C to produce

### Mathematical Formulation
**Maximize**: Z = 50x₁ + 80x₂ + 60x₃

**Subject to**:
- 2x₁ + 5x₂ + 3x₃ ≤ 1000 (Raw Material)
- 3x₁ + 4x₂ + 2x₃ ≤ 800 (Labor Hours)
- 1x₁ + 2x₂ + 1.5x₃ ≤ 600 (Machine Time)
- x₁ ≤ 150 (Product A demand)
- x₂ ≤ 100 (Product B demand)
- x₃ ≤ 200 (Product C demand)
- x₁, x₂, x₃ ≥ 0

---

## Problem 2: Assignment Problem - Task-Worker Allocation

### Objective
Assign 5 specialized assembly tasks to 5 workers to minimize total completion time.

### Workers
- Worker 1 (Alice): Senior technician, 8 years experience
- Worker 2 (Bob): Mid-level technician, 4 years experience
- Worker 3 (Carol): Junior technician, 2 years experience
- Worker 4 (David): Senior technician, 10 years experience
- Worker 5 (Emma): Mid-level technician, 5 years experience

### Tasks
- Task 1: Microchip quality inspection
- Task 2: Circuit board assembly
- Task 3: Sensor calibration
- Task 4: Component packaging
- Task 5: Final testing

### Cost Matrix (Time in hours)
Each cell represents the time a worker takes to complete a task:

|        | Task 1 | Task 2 | Task 3 | Task 4 | Task 5 |
|--------|--------|--------|--------|--------|--------|
| Alice  |   4    |   6    |   7    |   5    |   8    |
| Bob    |   6    |   5    |   8    |   7    |   6    |
| Carol  |   8    |   7    |   6    |   9    |   7    |
| David  |   3    |   4    |   6    |   4    |   5    |
| Emma   |   5    |   6    |   7    |   6    |   7    |

### Constraint
Each worker is assigned exactly one task, and each task is assigned to exactly one worker.

---

## Problem 3: Transportation Problem - Product Distribution

### Objective
Minimize transportation costs while meeting warehouse demand and factory supply constraints.

### Factories (Supply Sources)
- **Factory 1** (California): 300 units available
- **Factory 2** (Texas): 400 units available
- **Factory 3** (Ohio): 350 units available
- **Factory 4** (New York): 450 units available

**Total Supply**: 1,500 units

### Warehouses (Demand Destinations)
- **Warehouse 1** (Seattle): 250 units needed
- **Warehouse 2** (Denver): 300 units needed
- **Warehouse 3** (Chicago): 350 units needed
- **Warehouse 4** (Boston): 280 units needed
- **Warehouse 5** (Miami): 320 units needed

**Total Demand**: 1,500 units

### Transportation Cost Matrix ($ per unit)
Cost to ship one unit from factory i to warehouse j:

|           | Warehouse 1 | Warehouse 2 | Warehouse 3 | Warehouse 4 | Warehouse 5 |
|-----------|-------------|-------------|-------------|-------------|-------------|
| Factory 1 |      5      |      8      |     12      |     15      |     18      |
| Factory 2 |      9      |      6      |     10      |     13      |     14      |
| Factory 3 |     14      |     11      |      7      |      9      |     16      |
| Factory 4 |     17      |     15      |     10      |      6      |     12      |

### Constraints
- Supply from each factory cannot exceed available units
- Demand at each warehouse must be met exactly
- All shipments must be non-negative

---

## Dataset Details

### Linear Programming Dataset
- **File**: `lp_data.json`
- **Structure**:
  - Products: Array of objects with name, profit, and resource requirements
  - Resources: Array of constraints with name and availability
  - Market limits: Maximum demand for each product
- **Size**: 3 products, 3 resource types, 6 constraints total

### Assignment Problem Dataset
- **File**: `assignment_data.json`
- **Structure**:
  - Workers: Array with names and experience
  - Tasks: Array with task descriptions
  - Cost matrix: 5×5 matrix of completion times
- **Size**: 5 workers, 5 tasks, 25 time values

### Transportation Problem Dataset
- **File**: `transportation_data.json`
- **Structure**:
  - Factories: Array with locations and supply capacity
  - Warehouses: Array with locations and demand
  - Cost matrix: 4×5 matrix of transportation costs
- **Size**: 4 sources, 5 destinations, 20 cost values

---

## Methods and Algorithms Used

### 1. Linear Programming (Simplex Method)
- **Algorithm**: Scipy's `linprog` using Interior-Point or Simplex method
- **Approach**: Converts maximization to minimization, handles inequality constraints
- **Complexity**: O(n³) where n is number of variables

### 2. Assignment Problem (Hungarian Algorithm)
- **Algorithm**: Scipy's `linear_sum_assignment` (Hungarian method)
- **Approach**: Row/column reduction, covering zeros, finding optimal assignment
- **Complexity**: O(n³) where n is number of workers/tasks

### 3. Transportation Problem (Vogel's Approximation + MODI)
- **Initial Solution**: Vogel's Approximation Method (VAM)
- **Optimization**: Modified Distribution (MODI) method or Linear Programming
- **Approach**: Find initial feasible solution, then optimize iteratively
- **Complexity**: O(m×n) where m=sources, n=destinations

---

## Technology Stack

### Backend
- **Python 3.8+**: Core programming language
- **scipy.optimize**: Linear programming and assignment algorithms
- **numpy**: Numerical computations
- **Flask/FastAPI**: REST API framework
- **CORS**: Cross-origin resource sharing

### Frontend
- **React 18**: UI framework
- **Vite**: Build tool and dev server
- **Tailwind CSS**: Styling framework
- **Chart.js / Recharts**: Data visualization
- **Axios**: HTTP client for API calls

### Development Tools
- **VS Code**: IDE
- **Git**: Version control
- **Postman**: API testing

---

## Expected Outcomes

### Linear Programming Solution
- Optimal production quantities for Products A, B, C
- Maximum achievable profit
- Resource utilization analysis

### Assignment Solution
- Optimal worker-task assignments
- Minimum total completion time
- Individual worker assignments

### Transportation Solution
- Optimal shipment quantities from each factory to each warehouse
- Minimum total transportation cost
- Distribution plan matrix

---

## Business Impact

1. **Cost Reduction**: 15-25% reduction in transportation and operational costs
2. **Efficiency Improvement**: 30% better resource utilization
3. **Time Savings**: 20% reduction in task completion time
4. **Data-Driven Decisions**: Real-time optimization capabilities
5. **Scalability**: System can handle increased production capacity

---

## References

1. **Linear Programming**: Dantzig, G.B. (1947). "Linear Programming and Extensions"
2. **Assignment Problem**: Kuhn, H.W. (1955). "The Hungarian Method"
3. **Transportation Problem**: Hitchcock, F.L. (1941). "Distribution of a Product from Several Sources"
4. **Scipy Documentation**: https://docs.scipy.org/doc/scipy/reference/optimize.html
5. **Operations Research**: Taha, H.A. "Operations Research: An Introduction"
