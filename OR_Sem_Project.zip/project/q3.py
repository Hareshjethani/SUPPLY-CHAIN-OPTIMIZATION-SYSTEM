"""
Question 3: Transportation Problem - Product Distribution
==========================================================

Problem: Minimize transportation costs while distributing products from 4 factories
to 5 warehouses, meeting all demand and respecting supply constraints.

Method: Vogel's Approximation Method (VAM) for initial solution + 
        Linear Programming for optimization using scipy.optimize.linprog

Reference: 
- https://en.wikipedia.org/wiki/Transportation_theory_(mathematics)
- https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.linprog.html

Author: TechParts Inc. Operations Research Team
Date: December 2025
"""

import numpy as np
from scipy.optimize import linprog
import json
from typing import Dict, List, Tuple, Any, Optional


class TransportationProblemSolver:
    """
    Solves the Transportation Problem using Linear Programming.
    
    The transportation problem is a special case of linear programming where
    the goal is to minimize transportation costs from multiple sources (factories)
    to multiple destinations (warehouses) while satisfying supply and demand constraints.
    """
    
    def __init__(self, problem_data: Dict[str, Any]):
        """
        Initialize the Transportation Problem solver.
        
        Args:
            problem_data: Dictionary containing:
                - factories: List of factories with supply
                - warehouses: List of warehouses with demand
                - cost_matrix: m×n matrix of transportation costs
        """
        self.problem_data = problem_data
        self.factories = problem_data['factories']
        self.warehouses = problem_data['warehouses']
        self.cost_matrix = np.array(problem_data['cost_matrix'])
        
        self.m = len(self.factories)  # Number of sources
        self.n = len(self.warehouses)  # Number of destinations
        
        # Extract supply and demand
        self.supply = np.array([f['supply'] for f in self.factories])
        self.demand = np.array([w['demand'] for w in self.warehouses])
        
        # Validate problem
        self._validate_problem()
    
    def _validate_problem(self):
        """Validate that the transportation problem is well-formed."""
        total_supply = self.supply.sum()
        total_demand = self.demand.sum()
        
        if total_supply != total_demand:
            raise ValueError(
                f"Transportation problem is unbalanced: "
                f"Supply ({total_supply}) ≠ Demand ({total_demand}). "
                f"Problem must be balanced."
            )
        
        if self.cost_matrix.shape != (self.m, self.n):
            raise ValueError(
                f"Cost matrix shape {self.cost_matrix.shape} doesn't match "
                f"factories×warehouses ({self.m}×{self.n})"
            )
    
    def solve_with_linprog(self) -> Dict[str, Any]:
        """
        Solve using Linear Programming (scipy.linprog).
        
        Formulation:
            Minimize: Σ Σ c[i][j] * x[i][j]
            Subject to:
                Σ x[i][j] = supply[i]  for all i (supply constraints)
                Σ x[i][j] = demand[j]  for all j (demand constraints)
                x[i][j] ≥ 0           for all i,j (non-negativity)
        
        Returns:
            Solution dictionary with optimal shipments and cost
        """
        # Flatten cost matrix to 1D array (decision variables)
        c = self.cost_matrix.flatten()
        
        # Build equality constraint matrix
        # Each row represents one constraint
        A_eq = []
        b_eq = []
        
        # Supply constraints: each factory i must ship exactly supply[i] units
        for i in range(self.m):
            constraint = np.zeros(self.m * self.n)
            for j in range(self.n):
                constraint[i * self.n + j] = 1
            A_eq.append(constraint)
            b_eq.append(self.supply[i])
        
        # Demand constraints: each warehouse j must receive exactly demand[j] units
        for j in range(self.n):
            constraint = np.zeros(self.m * self.n)
            for i in range(self.m):
                constraint[i * self.n + j] = 1
            A_eq.append(constraint)
            b_eq.append(self.demand[j])
        
        A_eq = np.array(A_eq)
        b_eq = np.array(b_eq)
        
        # Bounds: all variables must be non-negative
        bounds = [(0, None) for _ in range(self.m * self.n)]
        
        # Solve
        result = linprog(
            c=c,
            A_eq=A_eq,
            b_eq=b_eq,
            bounds=bounds,
            method='highs',
            options={'disp': False}
        )
        
        if not result.success:
            return {
                'success': False,
                'message': f"Optimization failed: {result.message}",
                'shipments': None,
                'total_cost': None
            }
        
        # Reshape solution back to matrix form
        shipments = result.x.reshape(self.m, self.n)
        total_cost = result.fun
        
        return self._format_solution(shipments, total_cost, 'Linear Programming')
    
    def solve_with_vogel(self) -> Dict[str, Any]:
        """
        Solve using Vogel's Approximation Method (VAM).
        
        VAM is a heuristic that often provides near-optimal solutions:
        1. Calculate penalty for each row and column (difference between 
           two smallest costs)
        2. Select row/column with highest penalty
        3. Allocate maximum possible to cell with minimum cost in that row/column
        4. Repeat until all supply/demand is satisfied
        
        Returns:
            Solution dictionary with shipments and cost
        """
        # Create working copies
        supply_left = self.supply.copy()
        demand_left = self.demand.copy()
        shipments = np.zeros((self.m, self.n))
        cost_matrix = self.cost_matrix.copy()
        
        # Track which rows and columns are still active
        active_rows = set(range(self.m))
        active_cols = set(range(self.n))
        
        steps = []  # For visualization
        iteration = 0
        
        # Initial state
        steps.append({
            'iteration': 0,
            'description': 'Initial State',
            'supply_left': supply_left.copy().tolist(),
            'demand_left': demand_left.copy().tolist(),
            'shipments': shipments.copy().tolist(),
            'active_rows': list(active_rows),
            'active_cols': list(active_cols),
            'note': 'Starting Vogel\'s Approximation Method - all supply and demand is available'
        })
        
        while active_rows and active_cols:
            iteration += 1
            
            # Calculate penalties
            row_penalties = {}
            col_penalties = {}
            
            # Row penalties
            for i in active_rows:
                costs = [cost_matrix[i, j] for j in active_cols]
                if len(costs) >= 2:
                    costs_sorted = sorted(costs)
                    row_penalties[i] = costs_sorted[1] - costs_sorted[0]
                else:
                    row_penalties[i] = costs[0] if costs else 0
            
            # Column penalties
            for j in active_cols:
                costs = [cost_matrix[i, j] for i in active_rows]
                if len(costs) >= 2:
                    costs_sorted = sorted(costs)
                    col_penalties[j] = costs_sorted[1] - costs_sorted[0]
                else:
                    col_penalties[j] = costs[0] if costs else 0
            
            # Find maximum penalty
            max_row_penalty = max(row_penalties.values()) if row_penalties else -1
            max_col_penalty = max(col_penalties.values()) if col_penalties else -1
            
            # Choose row or column with highest penalty
            if max_row_penalty >= max_col_penalty:
                # Select row
                selected_row = max(row_penalties.keys(), 
                                 key=lambda k: row_penalties[k])
                # Find minimum cost cell in this row
                min_cost = float('inf')
                selected_col = None
                for j in active_cols:
                    if cost_matrix[selected_row, j] < min_cost:
                        min_cost = cost_matrix[selected_row, j]
                        selected_col = j
                penalty_type = 'row'
                penalty_value = row_penalties[selected_row]
            else:
                # Select column
                selected_col = max(col_penalties.keys(), 
                                 key=lambda k: col_penalties[k])
                # Find minimum cost cell in this column
                min_cost = float('inf')
                selected_row = None
                for i in active_rows:
                    if cost_matrix[i, selected_col] < min_cost:
                        min_cost = cost_matrix[i, selected_col]
                        selected_row = i
                penalty_type = 'column'
                penalty_value = col_penalties[selected_col]
            
            # Allocate maximum possible
            allocation = min(supply_left[selected_row], 
                           demand_left[selected_col])
            shipments[selected_row, selected_col] = allocation
            
            # Update supply and demand
            supply_left[selected_row] -= allocation
            demand_left[selected_col] -= allocation
            
            # Remove satisfied row or column
            row_satisfied = supply_left[selected_row] == 0
            col_satisfied = demand_left[selected_col] == 0
            
            if row_satisfied:
                active_rows.discard(selected_row)
            if col_satisfied:
                active_cols.discard(selected_col)
            
            steps.append({
                'iteration': iteration,
                'description': f'Iteration {iteration}: Allocate using highest penalty',
                'row_penalties': {int(k): float(v) for k, v in row_penalties.items()},
                'col_penalties': {int(k): float(v) for k, v in col_penalties.items()},
                'penalty_type': penalty_type,
                'penalty_value': float(penalty_value),
                'selected_row': int(selected_row),
                'selected_col': int(selected_col),
                'factory_name': self.factories[selected_row]['name'],
                'warehouse_name': self.warehouses[selected_col]['name'],
                'allocation': float(allocation),
                'cost': float(min_cost),
                'total_cost_this_allocation': float(allocation * min_cost),
                'supply_left': supply_left.copy().tolist(),
                'demand_left': demand_left.copy().tolist(),
                'shipments': shipments.copy().tolist(),
                'active_rows': list(active_rows),
                'active_cols': list(active_cols),
                'row_satisfied': row_satisfied,
                'col_satisfied': col_satisfied,
                'note': f'Allocated {allocation} units from {self.factories[selected_row]["name"]} to {self.warehouses[selected_col]["name"]} at cost ${min_cost}/unit'
            })
        
        total_cost = np.sum(shipments * self.cost_matrix)
        
        solution = self._format_solution(shipments, total_cost, 
                                         "Vogel's Approximation Method")
        solution['vam_steps'] = steps
        return solution
    
    def solve(self) -> Dict[str, Any]:
        """
        Solve using both methods and return the best solution.
        
        Returns:
            Best solution with comparison data
        """
        # Solve with both methods
        lp_solution = self.solve_with_linprog()
        vam_solution = self.solve_with_vogel()
        
        # Compare solutions
        if lp_solution['success']:
            best_solution = lp_solution
            best_solution['vam_cost'] = vam_solution['total_cost']
            best_solution['vam_optimality_gap'] = (
                (vam_solution['total_cost'] - lp_solution['total_cost']) / 
                lp_solution['total_cost'] * 100
            )
        else:
            best_solution = vam_solution
        
        return best_solution
    
    def _format_solution(self, shipments: np.ndarray, total_cost: float, 
                        method: str) -> Dict[str, Any]:
        """Format the solution into a structured dictionary."""
        # Build shipment details
        shipment_details = []
        for i in range(self.m):
            for j in range(self.n):
                quantity = shipments[i, j]
                if quantity > 0.01:  # Only include non-zero shipments
                    shipment_details.append({
                        'factory_id': int(i),
                        'factory_name': self.factories[i]['name'],
                        'warehouse_id': int(j),
                        'warehouse_name': self.warehouses[j]['name'],
                        'quantity': round(float(quantity), 2),
                        'unit_cost': float(self.cost_matrix[i, j]),
                        'total_cost': round(float(quantity * self.cost_matrix[i, j]), 2)
                    })
        
        # Calculate utilization
        factory_utilization = []
        for i in range(self.m):
            shipped = shipments[i, :].sum()
            factory_utilization.append({
                'factory': self.factories[i]['name'],
                'shipped': round(float(shipped), 2),
                'capacity': float(self.supply[i]),
                'utilization': round(float(shipped / self.supply[i] * 100), 2)
            })
        
        warehouse_received = []
        for j in range(self.n):
            received = shipments[:, j].sum()
            warehouse_received.append({
                'warehouse': self.warehouses[j]['name'],
                'received': round(float(received), 2),
                'demand': float(self.demand[j]),
                'fulfillment': round(float(received / self.demand[j] * 100), 2)
            })
        
        return {
            'success': True,
            'method': method,
            'total_cost': round(float(total_cost), 2),
            'shipments': shipments.round(2).tolist(),
            'shipment_details': shipment_details,
            'factory_utilization': factory_utilization,
            'warehouse_received': warehouse_received,
            'cost_matrix': self.cost_matrix.tolist(),
            'factory_names': [f['name'] for f in self.factories],
            'warehouse_names': [w['name'] for w in self.warehouses],
            'total_supply': float(self.supply.sum()),
            'total_demand': float(self.demand.sum()),
            'message': 'Transportation optimization successful'
        }
    
    def generate_report(self, solution: Dict[str, Any]) -> str:
        """Generate a detailed text report of the transportation solution."""
        if not solution['success']:
            return f"OPTIMIZATION FAILED\n{solution['message']}"
        
        report = []
        report.append("=" * 90)
        report.append("TRANSPORTATION PROBLEM OPTIMIZATION REPORT")
        report.append("TechParts Inc. - Product Distribution")
        report.append("=" * 90)
        report.append("")
        
        report.append(f"Method: {solution['method']}")
        report.append(f"Total Transportation Cost: ${solution['total_cost']:,.2f}")
        report.append("")
        
        report.append("SHIPMENT PLAN:")
        report.append("-" * 90)
        for shipment in solution['shipment_details']:
            report.append(
                f"  {shipment['factory_name']:20s} → {shipment['warehouse_name']:20s}: "
                f"{shipment['quantity']:6.0f} units @ ${shipment['unit_cost']:4.0f}/unit = "
                f"${shipment['total_cost']:8,.2f}"
            )
        report.append("")
        
        report.append("FACTORY UTILIZATION:")
        report.append("-" * 90)
        for factory in solution['factory_utilization']:
            report.append(
                f"  {factory['factory']:20s}: {factory['shipped']:6.0f} / "
                f"{factory['capacity']:6.0f} units ({factory['utilization']:5.1f}%)"
            )
        report.append("")
        
        report.append("WAREHOUSE DEMAND FULFILLMENT:")
        report.append("-" * 90)
        for warehouse in solution['warehouse_received']:
            report.append(
                f"  {warehouse['warehouse']:20s}: {warehouse['received']:6.0f} / "
                f"{warehouse['demand']:6.0f} units ({warehouse['fulfillment']:5.1f}%)"
            )
        report.append("")
        
        if 'vam_optimality_gap' in solution:
            report.append(f"VAM Heuristic vs Optimal: "
                         f"{solution['vam_optimality_gap']:.2f}% gap")
            report.append("")
        
        report.append("SHIPMENT MATRIX:")
        report.append("-" * 90)
        
        # Header
        header = "Factory          |"
        for warehouse in solution['warehouse_names']:
            header += f" {warehouse[:10]:^10s} |"
        header += " Total  |"
        report.append(header)
        report.append("-" * 90)
        
        # Matrix rows
        for i, factory_name in enumerate(solution['factory_names']):
            row = f"{factory_name:16s} |"
            row_total = 0
            for j in range(len(solution['warehouse_names'])):
                quantity = solution['shipments'][i][j]
                row_total += quantity
                if quantity > 0:
                    row += f"   {quantity:6.0f}  |"
                else:
                    row += f"      -    |"
            row += f" {row_total:6.0f} |"
            report.append(row)
        
        # Footer with demand totals
        footer = "Demand:          |"
        for j in range(len(solution['warehouse_names'])):
            col_total = sum(solution['shipments'][i][j] 
                          for i in range(len(solution['factory_names'])))
            footer += f"   {col_total:6.0f}  |"
        footer += f" {solution['total_demand']:6.0f} |"
        report.append("-" * 90)
        report.append(footer)
        
        report.append("")
        report.append("=" * 90)
        
        return "\n".join(report)


def load_problem_data(file_path: str = 'data/transportation_data.json') -> Dict[str, Any]:
    """Load problem data from JSON file."""
    try:
        with open(file_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return get_default_problem_data()


def get_default_problem_data() -> Dict[str, Any]:
    """Return default problem data for TechParts Inc."""
    return {
        "factories": [
            {"id": 0, "name": "Factory California", "location": "Los Angeles, CA", "supply": 300},
            {"id": 1, "name": "Factory Texas", "location": "Houston, TX", "supply": 400},
            {"id": 2, "name": "Factory Ohio", "location": "Cleveland, OH", "supply": 350},
            {"id": 3, "name": "Factory New York", "location": "Buffalo, NY", "supply": 450}
        ],
        "warehouses": [
            {"id": 0, "name": "Warehouse Seattle", "location": "Seattle, WA", "demand": 250},
            {"id": 1, "name": "Warehouse Denver", "location": "Denver, CO", "demand": 300},
            {"id": 2, "name": "Warehouse Chicago", "location": "Chicago, IL", "demand": 350},
            {"id": 3, "name": "Warehouse Boston", "location": "Boston, MA", "demand": 280},
            {"id": 4, "name": "Warehouse Miami", "location": "Miami, FL", "demand": 320}
        ],
        "cost_matrix": [
            [5, 8, 12, 15, 18],   # Factory California
            [9, 6, 10, 13, 14],   # Factory Texas
            [14, 11, 7, 9, 16],   # Factory Ohio
            [17, 15, 10, 6, 12]   # Factory New York
        ]
    }


def main():
    """Main function to run the Transportation Problem solver."""
    print("\n" + "=" * 90)
    print("TRANSPORTATION PROBLEM SOLVER - Q3")
    print("TechParts Inc. Product Distribution Optimization")
    print("=" * 90 + "\n")
    
    # Load problem data
    problem_data = load_problem_data()
    
    # Create solver instance
    solver = TransportationProblemSolver(problem_data)
    
    # Solve the problem
    print("Solving Transportation Problem...")
    print()
    solution = solver.solve()
    
    # Generate and print report
    report = solver.generate_report(solution)
    print(report)
    
    # Save solution to JSON
    try:
        with open('data/transportation_solution.json', 'w') as f:
            json.dump(solution, f, indent=2)
        print("\nSolution saved to: data/transportation_solution.json")
    except:
        pass
    
    return solution


if __name__ == "__main__":
    main()
