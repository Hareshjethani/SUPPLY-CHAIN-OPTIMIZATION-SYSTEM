# OR Project Startup Script
# Starts API server and frontend

$ErrorActionPreference = "SilentlyContinue"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  OR Project - Starting Servers" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Kill existing processes
Write-Host "Stopping existing processes..." -ForegroundColor Yellow
Get-Process | Where-Object {$_.ProcessName -match "python|node"} | ForEach-Object {
    try { Stop-Process -Id $_.Id -Force } catch { }
}
Start-Sleep -Seconds 2

# Change to project directory
Set-Location "C:\G\assignment work\capstone\oklan\project"

# Start API Server
Write-Host ""
Write-Host "Starting API Server..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd 'C:\G\assignment work\capstone\oklan\project'; python api_server.py" -WindowStyle Normal

Start-Sleep -Seconds 4

# Test API Server
try {
    $response = Invoke-WebRequest -Uri "http://localhost:5000/api/health" -UseBasicParsing -TimeoutSec 3
    Write-Host "API Server is running on http://localhost:5000" -ForegroundColor Green
} catch {
    Write-Host "API Server failed to start" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# Start Frontend
Write-Host ""
Write-Host "Starting Frontend Server..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd 'C:\G\assignment work\capstone\oklan\project\frontend'; npm run dev" -WindowStyle Normal

Start-Sleep -Seconds 3

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  All Servers Started!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "API Server:  http://localhost:5000" -ForegroundColor Yellow
Write-Host "Frontend:    http://localhost:3000" -ForegroundColor Yellow
Write-Host ""
Write-Host "Available Methods:" -ForegroundColor Cyan
Write-Host "   1. Linear Programming - 10 products, 20 constraints" -ForegroundColor White
Write-Host "   2. Assignment Problem - 10x10 matrix" -ForegroundColor White
Write-Host "   3. Transportation Problem - 10x10 matrix" -ForegroundColor White
Write-Host ""
Write-Host "Opening browser..." -ForegroundColor Green

Start-Sleep -Seconds 2
Start-Process "http://localhost:3000"

Write-Host ""
Write-Host "Servers are running in separate windows." -ForegroundColor Cyan
Write-Host "Close those windows to stop the servers." -ForegroundColor Gray
Write-Host ""
